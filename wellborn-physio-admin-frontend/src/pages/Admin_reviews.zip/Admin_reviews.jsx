import React, { useEffect, useState } from "react";
import {
  API,
  getData,
  putData,
  deleteData,
} from "../services/api";

import {
  Star,
  Trash2,
  MessageSquareText,
  ClipboardCheck,
  X,
  AlertTriangle,
  CheckCircle2,
  Loader2,
  ShieldAlert,
  RefreshCw,
} from "lucide-react";

/* =========================================================
   WELLBORN PHYSIO
   ADMIN REVIEWS

   MOBILE  : 2 COLUMNS
   TABLET  : 2 COLUMNS
   DESKTOP : 3 COLUMNS

   DARK MODE : wellborn-admin-dark

   DELETE:
   1. Confirmation
   2. Processing
   3. Success
   4. Error

   STATUS:
   1. Confirmation
   2. Processing
   3. Success
   4. Error

   STATUS OPTIONS:
   PENDING
   APPROVED
   REJECTED
========================================================= */

export default function Admin_reviews() {
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(true);

  const [updatingId, setUpdatingId] = useState(null);
  const [deletingId, setDeletingId] = useState(null);

  /* =======================================================
     DELETE POPUP STATE
  ======================================================= */

  const [deletePopup, setDeletePopup] = useState({
    open: false,
    id: null,
    review: null,
  });

  const [deleteProcess, setDeleteProcess] = useState({
    open: false,
  });

  const [deleteSuccess, setDeleteSuccess] = useState({
    open: false,
  });

  /* =======================================================
     STATUS CONFIRMATION POPUP
  ======================================================= */

  const [statusPopup, setStatusPopup] = useState({
    open: false,
    review: null,
    oldStatus: "",
    newStatus: "",
  });

  const [statusProcess, setStatusProcess] = useState({
    open: false,
  });

  const [statusSuccess, setStatusSuccess] = useState({
    open: false,
    oldStatus: "",
    newStatus: "",
  });

  /* =======================================================
     ERROR POPUP
  ======================================================= */

  const [deleteError, setDeleteError] = useState({
    open: false,
    message: "",
  });

  const [statusError, setStatusError] = useState({
    open: false,
    message: "",
  });

  /* =======================================================
     DARK MODE
  ======================================================= */

  const [darkMode, setDarkMode] = useState(() => {
    try {
      return document.documentElement.classList.contains(
        "wellborn-admin-dark"
      );
    } catch {
      return false;
    }
  });

  useEffect(() => {
    const root = document.documentElement;

    const updateTheme = () => {
      setDarkMode(
        root.classList.contains("wellborn-admin-dark")
      );
    };

    updateTheme();

    const observer = new MutationObserver(() => {
      updateTheme();
    });

    observer.observe(root, {
      attributes: true,
      attributeFilter: ["class"],
    });

    return () => observer.disconnect();
  }, []);

  /* =======================================================
     LOAD REVIEWS
  ======================================================= */

  const load = async () => {
    try {
      setLoading(true);

      const response = await getData(
        API.REVIEW_GET_ALL
      );

      setRows(
        Array.isArray(response)
          ? response
          : []
      );
    } catch (error) {
      console.error(
        "Reviews loading error:",
        error
      );

      setRows([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, []);

  /* =======================================================
     OPEN STATUS CONFIRMATION
  ======================================================= */

  const openStatusConfirmation = (
    review,
    newStatus
  ) => {
    if (!review?.reviewId) return;

    const currentStatus =
      review.status || "PENDING";

    /*
      Same status selected.
      No confirmation needed.
    */
    if (currentStatus === newStatus) {
      return;
    }

    setStatusPopup({
      open: true,
      review,
      oldStatus: currentStatus,
      newStatus,
    });
  };

  /* =======================================================
     CLOSE STATUS CONFIRMATION
  ======================================================= */

  const closeStatusConfirmation = () => {
    if (statusProcess.open) return;

    setStatusPopup({
      open: false,
      review: null,
      oldStatus: "",
      newStatus: "",
    });
  };

  /* =======================================================
     CONFIRM STATUS CHANGE
  ======================================================= */

  const confirmStatusChange = async () => {
    const review = statusPopup.review;
    const newStatus = statusPopup.newStatus;

    if (!review?.reviewId || !newStatus) {
      return;
    }

    const id = review.reviewId;

    /* Close confirmation */
    setStatusPopup({
      open: false,
      review: null,
      oldStatus: "",
      newStatus: "",
    });

    /* Open processing */
    setStatusProcess({
      open: true,
    });

    setUpdatingId(id);

    try {
      await putData(
        `${API.REVIEW_UPDATE}/${id}?status=${newStatus}`
      );

      /* Update UI immediately */
      setRows((previous) =>
        previous.map((item) =>
          item.reviewId === id
            ? {
                ...item,
                status: newStatus,
              }
            : item
        )
      );

      setStatusProcess({
        open: false,
      });

      setUpdatingId(null);

      setStatusSuccess({
        open: true,
        oldStatus: review.status || "PENDING",
        newStatus,
      });
    } catch (error) {
      console.error(
        "Review status update error:",
        error
      );

      setStatusProcess({
        open: false,
      });

      setUpdatingId(null);

      setStatusError({
        open: true,
        message:
          error?.message ||
          "Unable to update review status",
      });
    }
  };

  /* =======================================================
     CLOSE STATUS SUCCESS
  ======================================================= */

  const closeStatusSuccess = () => {
    setStatusSuccess({
      open: false,
      oldStatus: "",
      newStatus: "",
    });
  };

  /* =======================================================
     CLOSE STATUS ERROR
  ======================================================= */

  const closeStatusError = () => {
    setStatusError({
      open: false,
      message: "",
    });
  };

  /* =======================================================
     OPEN DELETE CONFIRMATION
  ======================================================= */

  const openDeleteConfirmation = (review) => {
    if (!review?.reviewId) return;

    setDeletePopup({
      open: true,
      id: review.reviewId,
      review,
    });
  };

  /* =======================================================
     CLOSE DELETE CONFIRMATION
  ======================================================= */

  const closeDeleteConfirmation = () => {
    if (deleteProcess.open) return;

    setDeletePopup({
      open: false,
      id: null,
      review: null,
    });
  };

  /* =======================================================
     CONFIRM DELETE
  ======================================================= */

  const confirmDelete = async () => {
    const id = deletePopup.id;

    if (!id) return;

    /* Close confirmation */
    setDeletePopup({
      open: false,
      id: null,
      review: null,
    });

    /* Open processing */
    setDeleteProcess({
      open: true,
    });

    setDeletingId(id);

    try {
      await deleteData(
        `${API.REVIEW_DELETE}/${id}`
      );

      /* Remove from UI */
      setRows((previous) =>
        previous.filter(
          (item) =>
            item.reviewId !== id
        )
      );

      setDeleteProcess({
        open: false,
      });

      setDeletingId(null);

      setDeleteSuccess({
        open: true,
      });
    } catch (error) {
      console.error(
        "Review delete error:",
        error
      );

      setDeleteProcess({
        open: false,
      });

      setDeletingId(null);

      setDeleteError({
        open: true,
        message:
          error?.message ||
          "Unable to delete review",
      });
    }
  };

  /* =======================================================
     CLOSE DELETE SUCCESS
  ======================================================= */

  const closeSuccessPopup = () => {
    setDeleteSuccess({
      open: false,
    });
  };

  /* =======================================================
     CLOSE DELETE ERROR
  ======================================================= */

  const closeDeleteError = () => {
    setDeleteError({
      open: false,
      message: "",
    });
  };

  /* =======================================================
     UI
  ======================================================= */

  return (
    <div
      className={`
        min-h-screen
        w-full
        min-w-0
        overflow-x-hidden
        transition-colors
        duration-300

        ${
          darkMode
            ? "bg-slate-950 text-slate-100"
            : "bg-slate-50 text-slate-900"
        }

        pt-[68px]
        px-2.5
        pb-4

        min-[380px]:pt-[72px]
        min-[380px]:px-3

        sm:pt-[82px]
        sm:px-5
        sm:pb-6

        lg:pt-[90px]
        lg:px-8
      `}
    >
      <div
        className="
          mx-auto
          w-full
          max-w-[1500px]
          min-w-0
        "
      >
        {/* =================================================
            PAGE HEADER
        ================================================= */}

        <section
          className={`
            mb-4
            w-full
            min-w-0
            overflow-hidden
            rounded-2xl
            border
            p-3

            min-[380px]:p-4

            sm:mb-6
            sm:p-6

            ${
              darkMode
                ? `
                  border-slate-700
                  bg-slate-900
                  shadow-lg
                  shadow-black/20
                `
                : `
                  border-slate-200
                  bg-white
                  shadow-md
                  shadow-slate-200/50
                `
            }
          `}
        >
          <div
            className="
              flex
              min-w-0
              items-center
              gap-2.5

              sm:gap-4
            "
          >
            {/* ICON */}

            <div
              className={`
                flex
                h-10
                w-10
                shrink-0
                items-center
                justify-center
                rounded-xl
                border

                min-[380px]:h-11
                min-[380px]:w-11

                sm:h-14
                sm:w-14
                sm:rounded-2xl

                ${
                  darkMode
                    ? `
                      border-cyan-400/30
                      bg-cyan-500/10
                      text-cyan-300
                    `
                    : `
                      border-cyan-100
                      bg-cyan-50
                      text-cyan-600
                    `
                }
              `}
            >
              <ClipboardCheck
                size={20}
                className="sm:hidden"
              />

              <ClipboardCheck
                size={25}
                className="hidden sm:block"
              />
            </div>

            {/* TITLE */}

            <div className="min-w-0 flex-1">
              <div
                className="
                  mb-0.5
                  flex
                  items-center
                  gap-1.5
                "
              >
                <span
                  className="
                    h-1.5
                    w-1.5
                    shrink-0
                    rounded-full
                    bg-emerald-500
                    animate-pulse
                  "
                />

                <span
                  className={`
                    truncate
                    text-[7px]
                    font-bold
                    uppercase
                    tracking-wider

                    min-[380px]:text-[8px]

                    sm:text-[10px]

                    ${
                      darkMode
                        ? "text-emerald-300"
                        : "text-emerald-600"
                    }
                  `}
                >
                  Admin Control
                </span>
              </div>

              <h1
                className={`
                  truncate
                  text-base
                  font-black
                  leading-tight

                  min-[380px]:text-lg

                  sm:text-2xl

                  lg:text-3xl

                  ${
                    darkMode
                      ? "text-white"
                      : "text-slate-900"
                  }
                `}
              >
                Reviews
              </h1>

              <p
                className={`
                  mt-0.5
                  truncate
                  text-[8px]

                  min-[380px]:text-[9px]

                  sm:text-xs

                  ${
                    darkMode
                      ? "text-slate-400"
                      : "text-slate-500"
                  }
                `}
              >
                Manage patient reviews and approval status
              </p>
            </div>
          </div>
        </section>

        {/* =================================================
            CONTENT
        ================================================= */}

        {loading ? (
          <LoadingCards
            darkMode={darkMode}
          />
        ) : rows.length === 0 ? (
          <EmptyState
            darkMode={darkMode}
          />
        ) : (
          <div
            className="
              grid
              w-full
              min-w-0
              grid-cols-2
              gap-2

              min-[380px]:gap-2.5

              sm:gap-4

              lg:grid-cols-3
              lg:gap-5
            "
          >
            {rows.map((review) => (
              <ReviewCard
                key={review.reviewId}
                review={review}
                darkMode={darkMode}
                onStatus={
                  openStatusConfirmation
                }
                onDelete={
                  openDeleteConfirmation
                }
                updatingId={updatingId}
                deletingId={deletingId}
              />
            ))}
          </div>
        )}
      </div>

      {/* =====================================================
          DELETE CONFIRMATION
      ===================================================== */}

      {deletePopup.open && (
        <DeleteConfirmationPopup
          darkMode={darkMode}
          review={deletePopup.review}
          onCancel={
            closeDeleteConfirmation
          }
          onConfirm={confirmDelete}
        />
      )}

      {/* =====================================================
          DELETE PROCESSING
      ===================================================== */}

      {deleteProcess.open && (
        <DeleteProcessingPopup
          darkMode={darkMode}
        />
      )}

      {/* =====================================================
          DELETE SUCCESS
      ===================================================== */}

      {deleteSuccess.open && (
        <DeleteSuccessPopup
          darkMode={darkMode}
          onClose={closeSuccessPopup}
        />
      )}

      {/* =====================================================
          DELETE ERROR
      ===================================================== */}

      {deleteError.open && (
        <ErrorPopup
          darkMode={darkMode}
          message={deleteError.message}
          onClose={closeDeleteError}
        />
      )}

      {/* =====================================================
          STATUS CONFIRMATION
      ===================================================== */}

      {statusPopup.open && (
        <StatusConfirmationPopup
          darkMode={darkMode}
          review={statusPopup.review}
          oldStatus={
            statusPopup.oldStatus
          }
          newStatus={
            statusPopup.newStatus
          }
          onCancel={
            closeStatusConfirmation
          }
          onConfirm={
            confirmStatusChange
          }
        />
      )}

      {/* =====================================================
          STATUS PROCESSING
      ===================================================== */}

      {statusProcess.open && (
        <StatusProcessingPopup
          darkMode={darkMode}
          newStatus={
            statusPopup.newStatus
          }
        />
      )}

      {/* =====================================================
          STATUS SUCCESS
      ===================================================== */}

      {statusSuccess.open && (
        <StatusSuccessPopup
          darkMode={darkMode}
          oldStatus={
            statusSuccess.oldStatus
          }
          newStatus={
            statusSuccess.newStatus
          }
          onClose={
            closeStatusSuccess
          }
        />
      )}

      {/* =====================================================
          STATUS ERROR
      ===================================================== */}

      {statusError.open && (
        <ErrorPopup
          darkMode={darkMode}
          message={statusError.message}
          onClose={closeStatusError}
        />
      )}
    </div>
  );
}

/* =========================================================
   REVIEW CARD
========================================================= */

function ReviewCard({
  review: r,
  darkMode,
  onStatus,
  onDelete,
  updatingId,
  deletingId,
}) {
  return (
    <div
      className={`
        group
        w-full
        min-w-0
        overflow-hidden
        rounded-xl
        border

        sm:rounded-2xl

        transition-all
        duration-200

        lg:hover:-translate-y-0.5

        ${
          darkMode
            ? `
              border-slate-700/80
              bg-slate-900
              shadow-lg
              shadow-black/20
              hover:border-slate-600
            `
            : `
              border-slate-200
              bg-white
              shadow-sm
              hover:border-slate-300
              hover:shadow-md
            `
        }
      `}
    >
      {/* CARD HEADER */}

      <div
        className={`
          border-b
          p-2.5

          min-[380px]:p-3

          sm:p-5

          ${
            darkMode
              ? "border-slate-700"
              : "border-slate-100"
          }
        `}
      >
        <div
          className="
            flex
            min-w-0
            items-start
            justify-between
            gap-1.5

            sm:gap-3
          "
        >
          {/* PATIENT */}

          <div className="min-w-0 flex-1">
            <h3
              className={`
                truncate
                text-[10px]
                font-black

                min-[380px]:text-[11px]

                sm:text-base

                ${
                  darkMode
                    ? "text-white"
                    : "text-slate-900"
                }
              `}
            >
              {r.patientName ||
                "Anonymous Patient"}
            </h3>

            <p
              className={`
                mt-1
                truncate
                text-[7px]

                min-[380px]:text-[8px]

                sm:text-xs

                ${
                  darkMode
                    ? "text-slate-400"
                    : "text-slate-500"
                }
              `}
            >
              {r.email ||
                "No email provided"}
            </p>
          </div>

          {/* RATING */}

          <div
            className={`
              flex
              shrink-0
              items-center
              gap-0

              rounded-lg
              border
              px-1.5
              py-1

              min-[380px]:px-2

              ${
                darkMode
                  ? `
                    border-amber-400/30
                    bg-amber-500/10
                  `
                  : `
                    border-amber-200
                    bg-amber-50
                  `
              }
            `}
          >
            {Array.from({
              length:
                Number(r.rating) || 0,
            }).map((_, index) => (
              <Star
                key={index}
                size={9}
                fill="currentColor"
                className="
                  text-amber-400

                  min-[380px]:h-2.5
                  min-[380px]:w-2.5

                  sm:h-3.5
                  sm:w-3.5
                "
              />
            ))}
          </div>
        </div>
      </div>

      {/* REVIEW BODY */}

      <div
        className="
          p-2.5

          min-[380px]:p-3

          sm:p-5
        "
      >
        <div
          className={`
            min-h-[95px]
            rounded-lg
            border
            p-2.5

            min-[380px]:min-h-[105px]
            min-[380px]:p-3

            sm:min-h-[140px]
            sm:rounded-xl
            sm:p-3.5

            ${
              darkMode
                ? `
                  border-slate-700
                  bg-slate-800
                `
                : `
                  border-slate-100
                  bg-slate-50
                `
            }
          `}
        >
          {/* LABEL */}

          <div
            className={`
              mb-2
              flex
              items-center
              gap-1

              text-[7px]
              font-black
              uppercase
              tracking-wider

              min-[380px]:text-[8px]

              sm:text-[9px]

              text-slate-400
            `}
          >
            <MessageSquareText
              size={10}
            />

            Patient Review
          </div>

          {/* TEXT */}

          <p
            className={`
              break-words
              whitespace-pre-wrap
              text-[9px]
              leading-relaxed

              min-[380px]:text-[10px]

              sm:text-sm

              ${
                darkMode
                  ? "text-slate-100"
                  : "text-slate-700"
              }
            `}
          >
            {r.reviewText ||
              "No review text available."}
          </p>
        </div>

        {/* STATUS + DELETE */}

        <div
          className="
            mt-2.5
            flex
            min-w-0
            items-center
            gap-1.5

            min-[380px]:mt-3
            min-[380px]:gap-2

            sm:mt-4
          "
        >
          {/* STATUS */}

          <select
            value={
              r.status || "PENDING"
            }
            disabled={
              updatingId ===
                r.reviewId ||
              deletingId ===
                r.reviewId
            }
            onChange={(e) =>
              onStatus(
                r,
                e.target.value
              )
            }
            className={`
              h-8
              min-w-0
              flex-1

              rounded-lg
              border

              px-1.5

              text-[7px]
              font-black

              outline-none

              transition

              min-[380px]:h-9
              min-[380px]:px-2
              min-[380px]:text-[8px]

              sm:h-10
              sm:rounded-xl
              sm:px-3
              sm:text-[10px]

              disabled:cursor-not-allowed
              disabled:opacity-60

              ${
                darkMode
                  ? `
                    border-slate-600
                    bg-slate-800
                    text-white
                    focus:border-cyan-400
                    focus:ring-2
                    focus:ring-cyan-400/20
                  `
                  : `
                    border-slate-200
                    bg-white
                    text-slate-800
                    focus:border-cyan-400
                    focus:ring-2
                    focus:ring-cyan-100
                  `
              }
            `}
          >
            <option
              value="PENDING"
              className={
                darkMode
                  ? "bg-slate-800 text-white"
                  : "bg-white text-slate-900"
              }
            >
              PENDING
            </option>

            <option
              value="APPROVED"
              className={
                darkMode
                  ? "bg-slate-800 text-white"
                  : "bg-white text-slate-900"
              }
            >
              APPROVED
            </option>

            <option
              value="REJECTED"
              className={
                darkMode
                  ? "bg-slate-800 text-white"
                  : "bg-white text-slate-900"
              }
            >
              REJECTED
            </option>
          </select>

          {/* DELETE */}

          <button
            type="button"
            onClick={() =>
              onDelete(r)
            }
            disabled={
              deletingId ===
              r.reviewId
            }
            aria-label="Delete review"
            title="Delete review"
            className={`
              flex
              h-8
              w-8
              shrink-0
              items-center
              justify-center

              rounded-lg
              border

              transition-all
              active:scale-95

              min-[380px]:h-9
              min-[380px]:w-9

              sm:h-10
              sm:w-10
              sm:rounded-xl

              disabled:cursor-not-allowed
              disabled:opacity-50

              ${
                darkMode
                  ? `
                    border-red-400/30
                    bg-red-500/10
                    text-red-300
                    hover:bg-red-500/20
                  `
                  : `
                    border-red-200
                    bg-red-50
                    text-red-600
                    hover:bg-red-100
                  `
              }
            `}
          >
            {deletingId ===
            r.reviewId ? (
              <span
                className={`
                  h-3
                  w-3
                  animate-spin
                  rounded-full
                  border-2
                  border-t-transparent

                  sm:h-4
                  sm:w-4

                  ${
                    darkMode
                      ? "border-red-300"
                      : "border-red-400"
                  }
                `}
              />
            ) : (
              <>
                <Trash2
                  size={13}
                  className="sm:hidden"
                />

                <Trash2
                  size={16}
                  className="hidden sm:block"
                />
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
}

/* =========================================================
   STATUS CONFIRMATION POPUP
========================================================= */

function StatusConfirmationPopup({
  darkMode,
  review,
  oldStatus,
  newStatus,
  onCancel,
  onConfirm,
}) {
  const isApproved =
    newStatus === "APPROVED";

  const isRejected =
    newStatus === "REJECTED";

  return (
    <div
      className="
        fixed
        inset-0
        z-[99999]
        flex
        min-h-screen
        items-center
        justify-center
        p-4
        animate-[fadeIn_0.2s_ease-out]
      "
    >
      {/* BACKDROP */}

      <div
        className="
          absolute
          inset-0
          bg-slate-950/75
          backdrop-blur-md
        "
        onClick={onCancel}
      />

      {/* POPUP */}

      <div
        className={`
          relative
          z-[100000]
          w-full
          max-w-[430px]

          overflow-hidden
          rounded-3xl
          border

          shadow-2xl
          shadow-black/40

          animate-[popupIn_0.25s_ease-out]

          ${
            darkMode
              ? `
                border-slate-700
                bg-slate-900
              `
              : `
                border-slate-200
                bg-white
              `
          }
        `}
      >
        {/* ACCENT */}

        <div
          className={`
            h-1
            w-full

            ${
              isApproved
                ? "bg-gradient-to-r from-emerald-500 via-green-500 to-emerald-500"
                : isRejected
                ? "bg-gradient-to-r from-red-500 via-orange-500 to-red-500"
                : "bg-gradient-to-r from-cyan-500 via-blue-500 to-cyan-500"
            }
          `}
        />

        {/* CLOSE */}

        <button
          type="button"
          onClick={onCancel}
          className={`
            absolute
            right-4
            top-4

            flex
            h-8
            w-8
            items-center
            justify-center

            rounded-full
            transition

            ${
              darkMode
                ? `
                  text-slate-400
                  hover:bg-slate-800
                  hover:text-white
                `
                : `
                  text-slate-400
                  hover:bg-slate-100
                  hover:text-slate-700
                `
            }
          `}
        >
          <X size={17} />
        </button>

        <div className="p-6 sm:p-7">
          {/* ICON */}

          <div
            className={`
              mx-auto
              mb-5
              flex
              h-16
              w-16
              items-center
              justify-center

              rounded-2xl
              border

              ${
                isApproved
                  ? `
                    border-emerald-300
                    bg-emerald-50
                    text-emerald-600
                  `
                  : isRejected
                  ? `
                    border-red-200
                    bg-red-50
                    text-red-600
                  `
                  : `
                    border-cyan-200
                    bg-cyan-50
                    text-cyan-600
                  `
              }

              ${
                darkMode
                  ? isApproved
                    ? `
                      border-emerald-400/30
                      bg-emerald-500/10
                      text-emerald-300
                    `
                    : isRejected
                    ? `
                      border-red-400/30
                      bg-red-500/10
                      text-red-300
                    `
                    : `
                      border-cyan-400/30
                      bg-cyan-500/10
                      text-cyan-300
                    `
                  : ""
              }
            `}
          >
            {isApproved ? (
              <CheckCircle2
                size={31}
                strokeWidth={1.8}
              />
            ) : isRejected ? (
              <ShieldAlert
                size={31}
                strokeWidth={1.8}
              />
            ) : (
              <RefreshCw
                size={31}
                strokeWidth={1.8}
              />
            )}
          </div>

          {/* TITLE */}

          <h2
            className={`
              text-center
              text-xl
              font-black

              ${
                darkMode
                  ? "text-white"
                  : "text-slate-900"
              }
            `}
          >
            Change Review Status?
          </h2>

          {/* DESCRIPTION */}

          <p
            className={`
              mx-auto
              mt-2
              max-w-[330px]
              text-center
              text-xs
              leading-relaxed

              ${
                darkMode
                  ? "text-slate-400"
                  : "text-slate-500"
              }
            `}
          >
            Are you sure you want to change
            this review status?
          </p>

          {/* STATUS CHANGE */}

          <div
            className={`
              mt-5
              flex
              items-center
              justify-center
              gap-2
              rounded-2xl
              border
              p-4

              ${
                darkMode
                  ? `
                    border-slate-700
                    bg-slate-950
                  `
                  : `
                    border-slate-200
                    bg-slate-50
                  `
              }
            `}
          >
            <StatusBadge
              status={oldStatus}
              darkMode={darkMode}
            />

            <span
              className={`
                text-lg
                font-black

                ${
                  darkMode
                    ? "text-slate-500"
                    : "text-slate-400"
                }
              `}
            >
              →
            </span>

            <StatusBadge
              status={newStatus}
              darkMode={darkMode}
            />
          </div>

          {/* PATIENT */}

          {review && (
            <div
              className={`
                mt-4
                rounded-2xl
                border
                p-3.5

                ${
                  darkMode
                    ? `
                      border-slate-700
                      bg-slate-950
                    `
                    : `
                      border-slate-200
                      bg-slate-50
                    `
                }
              `}
            >
              <p
                className={`
                  truncate
                  text-sm
                  font-black

                  ${
                    darkMode
                      ? "text-white"
                      : "text-slate-900"
                  }
                `}
              >
                {review.patientName ||
                  "Anonymous Patient"}
              </p>

              <p
                className={`
                  mt-0.5
                  truncate
                  text-[10px]

                  ${
                    darkMode
                      ? "text-slate-500"
                      : "text-slate-400"
                  }
                `}
              >
                {review.email ||
                  "No email provided"}
              </p>
            </div>
          )}

          {/* BUTTONS */}

          <div
            className="
              mt-6
              grid
              grid-cols-2
              gap-3
            "
          >
            <button
              type="button"
              onClick={onCancel}
              className={`
                h-11
                rounded-xl
                border

                text-xs
                font-black

                transition-all
                active:scale-[0.98]

                ${
                  darkMode
                    ? `
                      border-slate-700
                      bg-slate-800
                      text-slate-200
                      hover:bg-slate-700
                    `
                    : `
                      border-slate-200
                      bg-white
                      text-slate-700
                      hover:bg-slate-50
                    `
                }
              `}
            >
              Cancel
            </button>

            <button
              type="button"
              onClick={onConfirm}
              className={`
                h-11
                rounded-xl

                text-xs
                font-black
                text-white

                shadow-lg

                transition-all
                hover:-translate-y-0.5
                active:translate-y-0
                active:scale-[0.98]

                ${
                  isApproved
                    ? `
                      bg-gradient-to-r
                      from-emerald-600
                      to-emerald-500
                      shadow-emerald-500/20
                    `
                    : isRejected
                    ? `
                      bg-gradient-to-r
                      from-red-600
                      to-red-500
                      shadow-red-500/20
                    `
                    : `
                      bg-gradient-to-r
                      from-cyan-600
                      to-blue-500
                      shadow-cyan-500/20
                    `
                }
              `}
            >
              Confirm Change
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

/* =========================================================
   STATUS BADGE
========================================================= */

function StatusBadge({
  status,
  darkMode,
}) {
  const normalized =
    status || "PENDING";

  const styles = {
    APPROVED: darkMode
      ? "border-emerald-400/30 bg-emerald-500/10 text-emerald-300"
      : "border-emerald-200 bg-emerald-50 text-emerald-700",

    REJECTED: darkMode
      ? "border-red-400/30 bg-red-500/10 text-red-300"
      : "border-red-200 bg-red-50 text-red-700",

    PENDING: darkMode
      ? "border-amber-400/30 bg-amber-500/10 text-amber-300"
      : "border-amber-200 bg-amber-50 text-amber-700",
  };

  return (
    <span
      className={`
        rounded-xl
        border
        px-3
        py-2

        text-[9px]
        font-black
        tracking-wider

        ${styles[normalized] || styles.PENDING}
      `}
    >
      {normalized}
    </span>
  );
}

/* =========================================================
   STATUS PROCESSING POPUP
========================================================= */

function StatusProcessingPopup({
  darkMode,
  newStatus,
}) {
  return (
    <div
      className="
        fixed
        inset-0
        z-[99999]
        flex
        min-h-screen
        items-center
        justify-center
        p-4
      "
    >
      <div
        className="
          absolute
          inset-0
          bg-slate-950/80
          backdrop-blur-md
        "
      />

      <div
        className={`
          relative
          z-[100000]
          w-full
          max-w-[360px]

          rounded-3xl
          border

          p-7
          text-center

          shadow-2xl
          shadow-black/50

          animate-[popupIn_0.25s_ease-out]

          ${
            darkMode
              ? `
                border-slate-700
                bg-slate-900
              `
              : `
                border-slate-200
                bg-white
              `
          }
        `}
      >
        {/* LOADER */}

        <div
          className={`
            mx-auto
            mb-5
            flex
            h-16
            w-16
            items-center
            justify-center

            rounded-2xl
            border

            ${
              darkMode
                ? `
                  border-cyan-400/30
                  bg-cyan-500/10
                `
                : `
                  border-cyan-200
                  bg-cyan-50
                `
            }
          `}
        >
          <Loader2
            size={30}
            className={`
              animate-spin

              ${
                darkMode
                  ? "text-cyan-300"
                  : "text-cyan-600"
              }
            `}
          />
        </div>

        <h2
          className={`
            text-lg
            font-black

            ${
              darkMode
                ? "text-white"
                : "text-slate-900"
            }
          `}
        >
          Updating Status
        </h2>

        <p
          className={`
            mt-2
            text-xs
            leading-relaxed

            ${
              darkMode
                ? "text-slate-400"
                : "text-slate-500"
            }
          `}
        >
          Please wait while the review
          status is being updated to{" "}
          <strong>
            {newStatus}
          </strong>
          ...
        </p>

        {/* PROGRESS */}

        <div
          className={`
            mt-5
            h-1.5
            overflow-hidden
            rounded-full

            ${
              darkMode
                ? "bg-slate-800"
                : "bg-slate-100"
            }
          `}
        >
          <div
            className="
              h-full
              w-1/2
              animate-[loadingBar_1.2s_ease-in-out_infinite]
              rounded-full
              bg-gradient-to-r
              from-cyan-500
              to-blue-500
            "
          />
        </div>

        <p
          className={`
            mt-3
            text-[9px]
            font-bold
            uppercase
            tracking-widest

            ${
              darkMode
                ? "text-slate-500"
                : "text-slate-400"
            }
          `}
        >
          Processing...
        </p>
      </div>
    </div>
  );
}

/* =========================================================
   STATUS SUCCESS POPUP
========================================================= */

function StatusSuccessPopup({
  darkMode,
  oldStatus,
  newStatus,
  onClose,
}) {
  const isApproved =
    newStatus === "APPROVED";

  const isRejected =
    newStatus === "REJECTED";

  return (
    <div
      className="
        fixed
        inset-0
        z-[99999]
        flex
        min-h-screen
        items-center
        justify-center
        p-4
      "
    >
      <div
        className="
          absolute
          inset-0
          bg-slate-950/70
          backdrop-blur-md
        "
        onClick={onClose}
      />

      <div
        className={`
          relative
          z-[100000]
          w-full
          max-w-[370px]

          rounded-3xl
          border

          p-7
          text-center

          shadow-2xl
          shadow-black/50

          animate-[successPop_0.35s_ease-out]

          ${
            darkMode
              ? `
                border-slate-700
                bg-slate-900
              `
              : `
                border-slate-200
                bg-white
              `
          }
        `}
      >
        {/* SUCCESS ICON */}

        <div
          className={`
            relative
            mx-auto
            mb-5
            flex
            h-20
            w-20
            items-center
            justify-center

            rounded-full

            ${
              isApproved
                ? "bg-emerald-500/10"
                : isRejected
                ? "bg-red-500/10"
                : "bg-cyan-500/10"
            }
          `}
        >
          <div
            className={`
              absolute
              inset-0
              animate-ping
              rounded-full

              ${
                isApproved
                  ? "bg-emerald-500/10"
                  : isRejected
                  ? "bg-red-500/10"
                  : "bg-cyan-500/10"
              }
            `}
          />

          <div
            className={`
              relative
              flex
              h-16
              w-16
              items-center
              justify-center
              rounded-full
              text-white
              shadow-lg

              ${
                isApproved
                  ? `
                    bg-emerald-500
                    shadow-emerald-500/30
                  `
                  : isRejected
                  ? `
                    bg-red-500
                    shadow-red-500/30
                  `
                  : `
                    bg-cyan-500
                    shadow-cyan-500/30
                  `
              }
            `}
          >
            <CheckCircle2
              size={34}
              strokeWidth={2.5}
            />
          </div>
        </div>

        <h2
          className={`
            text-xl
            font-black

            ${
              darkMode
                ? "text-white"
                : "text-slate-900"
            }
          `}
        >
          Status Updated
        </h2>

        <p
          className={`
            mt-2
            text-xs
            leading-relaxed

            ${
              darkMode
                ? "text-slate-400"
                : "text-slate-500"
            }
          `}
        >
          The review status has been
          successfully updated.
        </p>

        {/* STATUS */}

        <div
          className="
            mt-5
            flex
            items-center
            justify-center
            gap-2
          "
        >
          <StatusBadge
            status={oldStatus}
            darkMode={darkMode}
          />

          <span
            className={`
              font-black

              ${
                darkMode
                  ? "text-slate-500"
                  : "text-slate-400"
              }
            `}
          >
            →
          </span>

          <StatusBadge
            status={newStatus}
            darkMode={darkMode}
          />
        </div>

        {/* DONE */}

        <button
          type="button"
          onClick={onClose}
          className={`
            mt-6
            h-11
            w-full
            rounded-xl

            text-xs
            font-black
            text-white

            shadow-lg

            transition-all
            hover:-translate-y-0.5
            active:translate-y-0
            active:scale-[0.98]

            ${
              isApproved
                ? `
                  bg-gradient-to-r
                  from-emerald-600
                  to-emerald-500
                  shadow-emerald-500/20
                `
                : isRejected
                ? `
                  bg-gradient-to-r
                  from-red-600
                  to-red-500
                  shadow-red-500/20
                `
                : `
                  bg-gradient-to-r
                  from-cyan-600
                  to-blue-500
                  shadow-cyan-500/20
                `
            }
          `}
        >
          Done
        </button>
      </div>
    </div>
  );
}

/* =========================================================
   DELETE CONFIRMATION POPUP
========================================================= */

function DeleteConfirmationPopup({
  darkMode,
  review,
  onCancel,
  onConfirm,
}) {
  return (
    <div
      className="
        fixed
        inset-0
        z-[99999]
        flex
        min-h-screen
        items-center
        justify-center
        p-4
        animate-[fadeIn_0.2s_ease-out]
      "
    >
      <div
        className="
          absolute
          inset-0
          bg-slate-950/75
          backdrop-blur-md
        "
        onClick={onCancel}
      />

      <div
        className={`
          relative
          z-[100000]
          w-full
          max-w-[430px]

          overflow-hidden
          rounded-3xl
          border

          shadow-2xl
          shadow-black/40

          animate-[popupIn_0.25s_ease-out]

          ${
            darkMode
              ? `
                border-slate-700
                bg-slate-900
              `
              : `
                border-slate-200
                bg-white
              `
          }
        `}
      >
        <div
          className="
            h-1
            w-full
            bg-gradient-to-r
            from-red-500
            via-orange-500
            to-red-500
          "
        />

        <button
          type="button"
          onClick={onCancel}
          className={`
            absolute
            right-4
            top-4

            flex
            h-8
            w-8
            items-center
            justify-center

            rounded-full
            transition

            ${
              darkMode
                ? `
                  text-slate-400
                  hover:bg-slate-800
                  hover:text-white
                `
                : `
                  text-slate-400
                  hover:bg-slate-100
                  hover:text-slate-700
                `
            }
          `}
        >
          <X size={17} />
        </button>

        <div className="p-6 sm:p-7">
          <div
            className={`
              mx-auto
              mb-5
              flex
              h-16
              w-16
              items-center
              justify-center

              rounded-2xl
              border

              ${
                darkMode
                  ? `
                    border-red-400/30
                    bg-red-500/10
                    text-red-300
                  `
                  : `
                    border-red-200
                    bg-red-50
                    text-red-600
                  `
              }
            `}
          >
            <ShieldAlert
              size={31}
              strokeWidth={1.8}
            />
          </div>

          <h2
            className={`
              text-center
              text-xl
              font-black

              ${
                darkMode
                  ? "text-white"
                  : "text-slate-900"
              }
            `}
          >
            Delete Review?
          </h2>

          <p
            className={`
              mx-auto
              mt-2
              max-w-[330px]
              text-center
              text-xs
              leading-relaxed

              ${
                darkMode
                  ? "text-slate-400"
                  : "text-slate-500"
              }
            `}
          >
            Are you sure you want to permanently
            delete this patient review?
            This action cannot be undone.
          </p>

          {review && (
            <div
              className={`
                mt-5
                rounded-2xl
                border
                p-3.5

                ${
                  darkMode
                    ? `
                      border-slate-700
                      bg-slate-950
                    `
                    : `
                      border-slate-200
                      bg-slate-50
                    `
                }
              `}
            >
              <div
                className="
                  flex
                  items-center
                  justify-between
                  gap-3
                "
              >
                <div className="min-w-0">
                  <p
                    className={`
                      truncate
                      text-sm
                      font-black

                      ${
                        darkMode
                          ? "text-white"
                          : "text-slate-900"
                      }
                    `}
                  >
                    {review.patientName ||
                      "Anonymous Patient"}
                  </p>

                  <p
                    className={`
                      mt-0.5
                      truncate
                      text-[10px]

                      ${
                        darkMode
                          ? "text-slate-500"
                          : "text-slate-400"
                      }
                    `}
                  >
                    {review.email ||
                      "No email provided"}
                  </p>
                </div>

                <div
                  className="
                    flex
                    shrink-0
                    items-center
                    gap-0.5
                  "
                >
                  {Array.from({
                    length:
                      Number(
                        review.rating
                      ) || 0,
                  }).map(
                    (_, index) => (
                      <Star
                        key={index}
                        size={12}
                        fill="currentColor"
                        className="text-amber-400"
                      />
                    )
                  )}
                </div>
              </div>

              <p
                className={`
                  mt-3
                  line-clamp-2
                  text-[10px]
                  leading-relaxed

                  ${
                    darkMode
                      ? "text-slate-400"
                      : "text-slate-500"
                  }
                `}
              >
                {review.reviewText ||
                  "No review text available."}
              </p>
            </div>
          )}

          <div
            className="
              mt-6
              grid
              grid-cols-2
              gap-3
            "
          >
            <button
              type="button"
              onClick={onCancel}
              className={`
                h-11
                rounded-xl
                border

                text-xs
                font-black

                transition-all
                active:scale-[0.98]

                ${
                  darkMode
                    ? `
                      border-slate-700
                      bg-slate-800
                      text-slate-200
                      hover:bg-slate-700
                    `
                    : `
                      border-slate-200
                      bg-white
                      text-slate-700
                      hover:bg-slate-50
                    `
                }
              `}
            >
              Cancel
            </button>

            <button
              type="button"
              onClick={onConfirm}
              className="
                h-11
                rounded-xl

                bg-gradient-to-r
                from-red-600
                to-red-500

                text-xs
                font-black
                text-white

                shadow-lg
                shadow-red-500/20

                transition-all
                hover:-translate-y-0.5
                active:translate-y-0
                active:scale-[0.98]
              "
            >
              Delete Review
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

/* =========================================================
   DELETE PROCESSING POPUP
========================================================= */

function DeleteProcessingPopup({
  darkMode,
}) {
  return (
    <div
      className="
        fixed
        inset-0
        z-[99999]
        flex
        min-h-screen
        items-center
        justify-center
        p-4
      "
    >
      <div
        className="
          absolute
          inset-0
          bg-slate-950/80
          backdrop-blur-md
        "
      />

      <div
        className={`
          relative
          z-[100000]
          w-full
          max-w-[360px]

          rounded-3xl
          border

          p-7
          text-center

          shadow-2xl
          shadow-black/50

          animate-[popupIn_0.25s_ease-out]

          ${
            darkMode
              ? `
                border-slate-700
                bg-slate-900
              `
              : `
                border-slate-200
                bg-white
              `
          }
        `}
      >
        <div
          className={`
            mx-auto
            mb-5
            flex
            h-16
            w-16
            items-center
            justify-center

            rounded-2xl
            border

            ${
              darkMode
                ? `
                  border-cyan-400/30
                  bg-cyan-500/10
                `
                : `
                  border-cyan-200
                  bg-cyan-50
                `
            }
          `}
        >
          <Loader2
            size={30}
            className={`
              animate-spin

              ${
                darkMode
                  ? "text-cyan-300"
                  : "text-cyan-600"
              }
            `}
          />
        </div>

        <h2
          className={`
            text-lg
            font-black

            ${
              darkMode
                ? "text-white"
                : "text-slate-900"
            }
          `}
        >
          Deleting Review
        </h2>

        <p
          className={`
            mt-2
            text-xs
            leading-relaxed

            ${
              darkMode
                ? "text-slate-400"
                : "text-slate-500"
            }
          `}
        >
          Please wait while we remove the
          review from the system...
        </p>

        <div
          className={`
            mt-5
            h-1.5
            overflow-hidden
            rounded-full

            ${
              darkMode
                ? "bg-slate-800"
                : "bg-slate-100"
            }
          `}
        >
          <div
            className="
              h-full
              w-1/2
              animate-[loadingBar_1.2s_ease-in-out_infinite]
              rounded-full
              bg-gradient-to-r
              from-cyan-500
              to-blue-500
            "
          />
        </div>

        <p
          className={`
            mt-3
            text-[9px]
            font-bold
            uppercase
            tracking-widest

            ${
              darkMode
                ? "text-slate-500"
                : "text-slate-400"
            }
          `}
        >
          Processing...
        </p>
      </div>
    </div>
  );
}

/* =========================================================
   DELETE SUCCESS POPUP
========================================================= */

function DeleteSuccessPopup({
  darkMode,
  onClose,
}) {
  return (
    <div
      className="
        fixed
        inset-0
        z-[99999]
        flex
        min-h-screen
        items-center
        justify-center
        p-4
      "
    >
      <div
        className="
          absolute
          inset-0
          bg-slate-950/70
          backdrop-blur-md
        "
        onClick={onClose}
      />

      <div
        className={`
          relative
          z-[100000]
          w-full
          max-w-[370px]

          rounded-3xl
          border

          p-7
          text-center

          shadow-2xl
          shadow-black/50

          animate-[successPop_0.35s_ease-out]

          ${
            darkMode
              ? `
                border-slate-700
                bg-slate-900
              `
              : `
                border-slate-200
                bg-white
              `
          }
        `}
      >
        <div
          className="
            relative
            mx-auto
            mb-5
            flex
            h-20
            w-20
            items-center
            justify-center

            rounded-full
            bg-emerald-500/10
          "
        >
          <div
            className="
              absolute
              inset-0
              animate-ping
              rounded-full
              bg-emerald-500/10
            "
          />

          <div
            className="
              relative
              flex
              h-16
              w-16
              items-center
              justify-center
              rounded-full
              bg-emerald-500
              text-white
              shadow-lg
              shadow-emerald-500/30
            "
          >
            <CheckCircle2
              size={34}
              strokeWidth={2.5}
            />
          </div>
        </div>

        <h2
          className={`
            text-xl
            font-black

            ${
              darkMode
                ? "text-white"
                : "text-slate-900"
            }
          `}
        >
          Review Deleted
        </h2>

        <p
          className={`
            mt-2
            text-xs
            leading-relaxed

            ${
              darkMode
                ? "text-slate-400"
                : "text-slate-500"
            }
          `}
        >
          The patient review has been
          successfully deleted.
        </p>

        <button
          type="button"
          onClick={onClose}
          className="
            mt-6
            h-11
            w-full
            rounded-xl

            bg-gradient-to-r
            from-emerald-600
            to-emerald-500

            text-xs
            font-black
            text-white

            shadow-lg
            shadow-emerald-500/20

            transition-all
            hover:-translate-y-0.5
            active:translate-y-0
            active:scale-[0.98]
          "
        >
          Done
        </button>
      </div>
    </div>
  );
}

/* =========================================================
   ERROR POPUP
========================================================= */

function ErrorPopup({
  darkMode,
  message,
  onClose,
}) {
  return (
    <div
      className="
        fixed
        inset-0
        z-[99999]
        flex
        min-h-screen
        items-center
        justify-center
        p-4
      "
    >
      <div
        className="
          absolute
          inset-0
          bg-slate-950/75
          backdrop-blur-md
        "
        onClick={onClose}
      />

      <div
        className={`
          relative
          z-[100000]
          w-full
          max-w-[380px]

          rounded-3xl
          border
          p-7

          text-center

          shadow-2xl

          animate-[popupIn_0.25s_ease-out]

          ${
            darkMode
              ? `
                border-slate-700
                bg-slate-900
              `
              : `
                border-slate-200
                bg-white
              `
          }
        `}
      >
        <div
          className="
            mx-auto
            mb-5
            flex
            h-16
            w-16
            items-center
            justify-center
            rounded-2xl
            bg-red-500/10
            text-red-500
          "
        >
          <AlertTriangle
            size={30}
          />
        </div>

        <h2
          className={`
            text-lg
            font-black

            ${
              darkMode
                ? "text-white"
                : "text-slate-900"
            }
          `}
        >
          Something Went Wrong
        </h2>

        <p
          className={`
            mt-2
            text-xs
            leading-relaxed

            ${
              darkMode
                ? "text-slate-400"
                : "text-slate-500"
            }
          `}
        >
          {message}
        </p>

        <button
          type="button"
          onClick={onClose}
          className="
            mt-6
            h-11
            w-full
            rounded-xl
            bg-red-600
            text-xs
            font-black
            text-white
            transition
            hover:bg-red-700
            active:scale-[0.98]
          "
        >
          Close
        </button>
      </div>
    </div>
  );
}

/* =========================================================
   LOADING CARDS
========================================================= */

function LoadingCards({
  darkMode,
}) {
  return (
    <div
      className="
        grid
        w-full
        min-w-0
        grid-cols-2
        gap-2

        min-[380px]:gap-2.5

        sm:gap-4

        lg:grid-cols-3
        lg:gap-5
      "
    >
      {[1, 2, 3, 4, 5, 6].map(
        (item) => (
          <div
            key={item}
            className={`
              h-[210px]
              animate-pulse
              rounded-xl
              border

              min-[380px]:h-[230px]

              sm:h-[280px]
              sm:rounded-2xl

              ${
                darkMode
                  ? `
                    border-slate-700
                    bg-slate-900
                  `
                  : `
                    border-slate-200
                    bg-white
                  `
              }
            `}
          />
        )
      )}
    </div>
  );
}

/* =========================================================
   EMPTY STATE
========================================================= */

function EmptyState({
  darkMode,
}) {
  return (
    <div
      className={`
        flex
        min-h-[260px]
        w-full
        flex-col
        items-center
        justify-center

        rounded-2xl
        border
        border-dashed

        px-5
        text-center

        sm:min-h-[320px]

        ${
          darkMode
            ? `
              border-slate-600
              bg-slate-900
            `
            : `
              border-slate-300
              bg-white
            `
        }
      `}
    >
      <div
        className={`
          mb-4
          flex
          h-12
          w-12
          items-center
          justify-center

          rounded-xl

          ${
            darkMode
              ? `
                bg-slate-800
                text-slate-300
              `
              : `
                bg-slate-100
                text-slate-400
              `
          }
        `}
      >
        <MessageSquareText
          size={22}
        />
      </div>

      <h3
        className={`
          text-sm
          font-black

          sm:text-base

          ${
            darkMode
              ? "text-white"
              : "text-slate-900"
          }
        `}
      >
        No reviews found
      </h3>

      <p
        className={`
          mt-1
          max-w-sm
          text-[10px]
          leading-relaxed

          sm:text-xs

          ${
            darkMode
              ? "text-slate-400"
              : "text-slate-500"
          }
        `}
      >
        Patient reviews will appear here
        when users submit them.
      </p>
    </div>
  );
}

/* =========================================================
   POPUP ANIMATIONS
========================================================= */

const popupStyles = `
@keyframes popupIn {
  0% {
    opacity: 0;
    transform: scale(0.92) translateY(12px);
  }

  100% {
    opacity: 1;
    transform: scale(1) translateY(0);
  }
}

@keyframes successPop {
  0% {
    opacity: 0;
    transform: scale(0.75);
  }

  60% {
    opacity: 1;
    transform: scale(1.04);
  }

  100% {
    opacity: 1;
    transform: scale(1);
  }
}

@keyframes fadeIn {
  0% {
    opacity: 0;
  }

  100% {
    opacity: 1;
  }
}

@keyframes loadingBar {
  0% {
    transform: translateX(-120%);
  }

  50% {
    transform: translateX(100%);
  }

  100% {
    transform: translateX(220%);
  }
}
`;

/* =========================================================
   INJECT POPUP ANIMATIONS
========================================================= */

if (
  typeof document !== "undefined" &&
  !document.getElementById(
    "wellborn-review-popup-styles"
  )
) {
  const style =
    document.createElement(
      "style"
    );

  style.id =
    "wellborn-review-popup-styles";

  style.innerHTML = popupStyles;

  document.head.appendChild(
    style
  );
}