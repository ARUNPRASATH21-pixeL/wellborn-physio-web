import React, { useEffect, useState } from "react";
import {
  API,
  getData,
  postData,
  putData,
  deleteData,
} from "../services/api";

import {
  Plus,
  Pencil,
  Trash2,
  X,
  Search,
  Layers,
  CheckCircle2,
  XCircle,
  AlertTriangle,
} from "lucide-react";

const empty = {
  serviceName: "",
  description: "",
  image: "",
  status: true,
};

/* =========================================================
   VALIDATION LIMITS
========================================================= */

const VALIDATION = {
  serviceNameMin: 2,
  serviceNameMax: 100,
  descriptionMin: 10,
  descriptionMax: 1000,
  imageMax: 500,
};

/* =========================================================
   ADMIN SERVICES
========================================================= */

export default function Admin_services() {
  const [darkMode, setDarkMode] = useState(() => {
    try {
      return document.documentElement.classList.contains(
        "wellborn-admin-dark"
      );
    } catch {
      return false;
    }
  });

  useEffect(() => {
    const root = document.documentElement;

    const updateTheme = () => {
      setDarkMode(
        root.classList.contains("wellborn-admin-dark")
      );
    };

    updateTheme();

    const observer = new MutationObserver(updateTheme);

    observer.observe(root, {
      attributes: true,
      attributeFilter: ["class"],
    });

    return () => observer.disconnect();
  }, []);

  const [rows, setRows] = useState([]);
  const [form, setForm] = useState({ ...empty });
  const [errors, setErrors] = useState({});
  const [edit, setEdit] = useState(null);

  const [open, setOpen] = useState(false);

  const [deleteModal, setDeleteModal] = useState(false);
  const [selectedDelete, setSelectedDelete] = useState(null);

  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [deletingId, setDeletingId] = useState(null);

  /* =========================================================
     POPUP STATE
  ========================================================= */

  const [popup, setPopup] = useState({
    show: false,
    type: "success",
    title: "",
    message: "",
  });

  const showPopup = (type, title, message) => {
    setPopup({
      show: true,
      type,
      title,
      message,
    });

    setTimeout(() => {
      setPopup((previous) => ({
        ...previous,
        show: false,
      }));
    }, 2600);
  };

  const closePopup = () => {
    setPopup((previous) => ({
      ...previous,
      show: false,
    }));
  };

  /* =========================================================
     LOAD
  ========================================================= */

  const load = async () => {
    try {
      setLoading(true);

      const response = await getData(API.SERVICE_GET_ALL);

      setRows(Array.isArray(response) ? response : []);
    } catch (error) {
      console.error("Service loading error:", error);
      setRows([]);

      showPopup(
        "error",
        "Loading Failed",
        "Unable to load services."
      );
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, []);

  /* =========================================================
     ADD
  ========================================================= */

  const openAdd = () => {
    setEdit(null);
    setForm({ ...empty });
    setErrors({});
    setOpen(true);
  };

  /* =========================================================
     EDIT
  ========================================================= */

  const openEdit = (service) => {
    setEdit(service.serviceId);

    setForm({
      serviceName: service.serviceName || "",
      description: service.description || "",
      image: service.image || "",
      status:
        service.status === undefined
          ? true
          : Boolean(service.status),
    });

    setErrors({});
    setOpen(true);
  };

  /* =========================================================
     CLOSE
  ========================================================= */

  const closeModal = () => {
    if (saving) return;

    setOpen(false);
    setEdit(null);
    setForm({ ...empty });
    setErrors({});
  };

  /* =========================================================
     URL VALIDATION
  ========================================================= */

  const isValidImageUrl = (value) => {
    const url = value.trim();

    if (!url) return false;

    try {
      const parsed = new URL(url);

      if (
        parsed.protocol !== "http:" &&
        parsed.protocol !== "https:"
      ) {
        return false;
      }

      return Boolean(parsed.hostname);
    } catch {
      return false;
    }
  };

  /* =========================================================
     FORM VALIDATION
  ========================================================= */

  const validateForm = () => {
    const newErrors = {};

    const serviceName = form.serviceName.trim();
    const description = form.description.trim();
    const image = form.image.trim();

    /* SERVICE NAME */

    if (!serviceName) {
      newErrors.serviceName =
        "Service name is required.";
    } else if (
      serviceName.length <
      VALIDATION.serviceNameMin
    ) {
      newErrors.serviceName =
        `Service name must be at least ${VALIDATION.serviceNameMin} characters.`;
    } else if (
      serviceName.length >
      VALIDATION.serviceNameMax
    ) {
      newErrors.serviceName =
        `Service name must not exceed ${VALIDATION.serviceNameMax} characters.`;
    }

    /* DESCRIPTION */

    if (!description) {
      newErrors.description =
        "Description is required.";
    } else if (
      description.length <
      VALIDATION.descriptionMin
    ) {
      newErrors.description =
        `Description must be at least ${VALIDATION.descriptionMin} characters.`;
    } else if (
      description.length >
      VALIDATION.descriptionMax
    ) {
      newErrors.description =
        `Description must not exceed ${VALIDATION.descriptionMax} characters.`;
    }

    /* IMAGE URL */

    if (!image) {
      newErrors.image =
        "Image URL is required.";
    } else if (image.length > VALIDATION.imageMax) {
      newErrors.image =
        `Image URL must not exceed ${VALIDATION.imageMax} characters.`;
    } else if (!isValidImageUrl(image)) {
      newErrors.image =
        "Please enter a valid image URL starting with http:// or https://.";
    }

    /* STATUS */

    if (
      typeof form.status !== "boolean"
    ) {
      newErrors.status =
        "Please select service status.";
    }

    setErrors(newErrors);

    return Object.keys(newErrors).length === 0;
  };

  /* =========================================================
     FIELD CHANGE
  ========================================================= */

  const updateField = (field, value) => {
    setForm((previous) => ({
      ...previous,
      [field]: value,
    }));

    /*
      Remove that field's error while user is correcting it.
    */

    if (errors[field]) {
      setErrors((previous) => ({
        ...previous,
        [field]: "",
      }));
    }
  };

  /* =========================================================
     SAVE / UPDATE
  ========================================================= */

  const save = async (e) => {
    e.preventDefault();

    if (saving) return;

    /*
      IMPORTANT:
      Validation happens BEFORE API call.
      So empty image URL cannot be added/updated.
    */

    const valid = validateForm();

    if (!valid) {
      showPopup(
        "error",
        "Validation Failed",
        "Please correct the highlighted fields."
      );

      return;
    }

    try {
      setSaving(true);

      const payload = {
        serviceName: form.serviceName.trim(),
        description: form.description.trim(),
        image: form.image.trim(),
        status: Boolean(form.status),
      };

      if (edit) {
        await putData(
          `${API.SERVICE_UPDATE}/${edit}`,
          payload
        );

        setOpen(false);
        setEdit(null);
        setForm({ ...empty });
        setErrors({});

        await load();

        showPopup(
          "success",
          "Service Updated",
          "Service updated successfully."
        );
      } else {
        await postData(
          API.SERVICE_ADD,
          payload
        );

        setOpen(false);
        setEdit(null);
        setForm({ ...empty });
        setErrors({});

        await load();

        showPopup(
          "success",
          "Service Added",
          "Service added successfully."
        );
      }
    } catch (error) {
      console.error("Service save error:", error);

      showPopup(
        "error",
        "Save Failed",
        error?.message ||
          "Unable to save service."
      );
    } finally {
      setSaving(false);
    }
  };

  /* =========================================================
     DELETE
  ========================================================= */

  const openDelete = (service) => {
    if (deletingId) return;

    setSelectedDelete(service);
    setDeleteModal(true);
  };

  const closeDelete = () => {
    if (deletingId) return;

    setDeleteModal(false);
    setSelectedDelete(null);
  };

  const remove = async () => {
    if (!selectedDelete) return;

    const id = selectedDelete.serviceId;

    try {
      setDeletingId(id);

      await deleteData(
        `${API.SERVICE_DELETE}/${id}`
      );

      setRows((previous) =>
        previous.filter(
          (service) =>
            service.serviceId !== id
        )
      );

      setDeleteModal(false);
      setSelectedDelete(null);

      showPopup(
        "success",
        "Service Deleted",
        "Service deleted successfully."
      );
    } catch (error) {
      console.error(
        "Service delete error:",
        error
      );

      showPopup(
        "error",
        "Delete Failed",
        error?.message ||
          "Unable to delete service."
      );
    } finally {
      setDeletingId(null);
    }
  };

  /* =========================================================
     SEARCH
  ========================================================= */

  const searchText = search
    .trim()
    .toLowerCase();

  const filtered = rows.filter((service) => {
    if (!searchText) return true;

    return JSON.stringify(service)
      .toLowerCase()
      .includes(searchText);
  });

  return (
    <div
      className={`relative min-h-screen w-full transition-colors duration-300 ${
        darkMode
          ? "bg-slate-950 text-slate-100"
          : "bg-slate-50 text-slate-900"
      }`}
    >
      {/* =====================================================
          TOP SUCCESS / ERROR POPUP
      ===================================================== */}

      <ServicePopup
        popup={popup}
        close={closePopup}
        darkMode={darkMode}
      />

      <main className="relative z-10 mx-auto w-full max-w-7xl px-4 pb-28 pt-[80px] sm:px-6 sm:pt-[90px] lg:px-8">

        {/* HEADER */}

        <section
          className={`mb-6 w-full rounded-2xl border p-4 sm:p-6 ${
            darkMode
              ? "border-slate-700 bg-slate-900 shadow-lg"
              : "border-slate-200 bg-white shadow-sm"
          }`}
        >
          <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">

            <div className="flex items-center gap-3">
              <div
                className={`flex h-12 w-12 shrink-0 items-center justify-center rounded-xl border ${
                  darkMode
                    ? "border-cyan-500/30 bg-cyan-500/10 text-cyan-400"
                    : "border-cyan-100 bg-cyan-50 text-cyan-600"
                }`}
              >
                <Layers size={22} />
              </div>

              <div>
                <div className="mb-1 flex items-center gap-1.5">
                  <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-emerald-500" />

                  <span
                    className={`text-[10px] font-bold uppercase tracking-wider ${
                      darkMode
                        ? "text-emerald-400"
                        : "text-emerald-600"
                    }`}
                  >
                    Admin Control
                  </span>
                </div>

                <h1 className="text-xl font-black sm:text-2xl">
                  Services
                </h1>
              </div>
            </div>

            <div className="flex flex-col gap-3 sm:flex-row">

              <div className="relative w-full sm:w-[260px]">
                <Search
                  size={16}
                  className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400"
                />

                <input
                  value={search}
                  onChange={(e) =>
                    setSearch(e.target.value)
                  }
                  placeholder="Search services..."
                  className={`h-11 w-full rounded-xl border pl-10 pr-4 text-sm font-medium outline-none ${
                    darkMode
                      ? "border-slate-700 bg-slate-800 text-white focus:border-cyan-500"
                      : "border-slate-200 bg-slate-50 text-slate-900 focus:border-cyan-500"
                  }`}
                />
              </div>

              <button
                type="button"
                onClick={openAdd}
                className="flex h-11 items-center justify-center gap-2 rounded-xl bg-cyan-600 px-5 text-sm font-bold text-white transition-all hover:bg-cyan-700 active:scale-95"
              >
                <Plus size={18} />
                Add Service
              </button>

            </div>
          </div>
        </section>

        {/* TITLE */}

        <div className="mb-4 flex items-center gap-2">
          <div
            className={`flex h-8 w-8 items-center justify-center rounded-lg ${
              darkMode
                ? "bg-cyan-500/10 text-cyan-400"
                : "bg-cyan-50 text-cyan-600"
            }`}
          >
            <Layers size={16} />
          </div>

          <h2 className="text-lg font-black">
            Service Overview
          </h2>
        </div>

        {/* CARDS */}

        {loading ? (
          <LoadingCards darkMode={darkMode} />
        ) : filtered.length === 0 ? (
          <EmptyState darkMode={darkMode} />
        ) : (
          <div className="grid w-full grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {filtered.map((service) => (
              <ServiceCard
                key={service.serviceId}
                service={service}
                onEdit={openEdit}
                onDelete={openDelete}
                deletingId={deletingId}
                darkMode={darkMode}
              />
            ))}
          </div>
        )}
      </main>

      {/* =====================================================
          IOS ADD / EDIT MODAL
      ===================================================== */}

      {open && (
        <IOSServiceModal
          edit={edit}
          form={form}
          errors={errors}
          updateField={updateField}
          save={save}
          close={closeModal}
          saving={saving}
          darkMode={darkMode}
        />
      )}

      {/* DELETE */}

      {deleteModal && selectedDelete && (
        <DeleteModal
          service={selectedDelete}
          close={closeDelete}
          confirm={remove}
          deleting={
            deletingId ===
            selectedDelete.serviceId
          }
          darkMode={darkMode}
        />
      )}
    </div>
  );
}

/* =========================================================
   SUCCESS / ERROR POPUP
========================================================= */

function ServicePopup({
  popup,
  close,
  darkMode,
}) {
  if (!popup.show) return null;

  const success =
    popup.type === "success";

  return (
    <div
      className="fixed left-1/2 top-4 z-[20000] w-[calc(100%-24px)] max-w-[420px] -translate-x-1/2 px-1 sm:top-6"
      style={{
        paddingTop:
          "env(safe-area-inset-top)",
      }}
    >
      <div
        className={`relative overflow-hidden rounded-2xl border p-4 shadow-2xl backdrop-blur-2xl ${
          darkMode
            ? "border-white/10 bg-[#18191d]/95"
            : "border-black/[0.06] bg-white/95"
        }`}
        style={{
          animation:
            "servicePopupIn .35s cubic-bezier(.22,1,.36,1)",
        }}
      >
        <div className="flex items-center gap-3">

          <div
            className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-xl ${
              success
                ? darkMode
                  ? "bg-emerald-500/15 text-emerald-400"
                  : "bg-emerald-50 text-emerald-600"
                : darkMode
                ? "bg-red-500/15 text-red-400"
                : "bg-red-50 text-red-600"
            }`}
          >
            {success ? (
              <CheckCircle2 size={22} />
            ) : (
              <XCircle size={22} />
            )}
          </div>

          <div className="min-w-0 flex-1">
            <p
              className={`text-sm font-black ${
                darkMode
                  ? "text-white"
                  : "text-slate-900"
              }`}
            >
              {popup.title}
            </p>

            <p
              className={`mt-0.5 truncate text-xs font-medium ${
                darkMode
                  ? "text-slate-400"
                  : "text-slate-500"
              }`}
            >
              {popup.message}
            </p>
          </div>

          <button
            type="button"
            onClick={close}
            className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-full ${
              darkMode
                ? "bg-white/10 text-slate-300 hover:bg-white/15"
                : "bg-black/[0.05] text-slate-500 hover:bg-black/[0.08]"
            }`}
          >
            <X size={15} />
          </button>
        </div>

        <div
          className={`absolute bottom-0 left-0 h-[3px] ${
            success
              ? "bg-emerald-500"
              : "bg-red-500"
          }`}
          style={{
            width: "100%",
            animation:
              "servicePopupProgress 2.6s linear forwards",
          }}
        />
      </div>

      <style>
        {`
          @keyframes servicePopupIn {
            0% {
              opacity: 0;
              transform: translateY(-18px) scale(.96);
            }
            100% {
              opacity: 1;
              transform: translateY(0) scale(1);
            }
          }

          @keyframes servicePopupProgress {
            0% {
              width: 100%;
            }
            100% {
              width: 0%;
            }
          }
        `}
      </style>
    </div>
  );
}

/* =========================================================
   IOS SERVICE MODAL
========================================================= */

function IOSServiceModal({
  edit,
  form,
  errors,
  updateField,
  save,
  close,
  saving,
  darkMode,
}) {
  return (
    <div
      className="fixed inset-0 z-[9999] flex items-start justify-center overflow-y-auto bg-black/45 p-3 backdrop-blur-xl sm:items-center sm:p-5"
      style={{
        paddingTop:
          "max(12px, env(safe-area-inset-top))",
        paddingBottom:
          "max(12px, env(safe-area-inset-bottom))",
      }}
    >
      <div
        className={`relative my-auto w-full max-w-[520px] overflow-hidden rounded-[28px] border shadow-2xl ${
          darkMode
            ? "border-white/10 bg-[#17181c]/95 text-white"
            : "border-white/80 bg-[#f7f7f9]/95 text-[#111111]"
        }`}
      >

        <div
          className={`sticky top-0 z-10 border-b px-5 py-4 backdrop-blur-2xl sm:px-6 ${
            darkMode
              ? "border-white/10 bg-[#17181c]/90"
              : "border-black/5 bg-[#f7f7f9]/90"
          }`}
        >
          <div className="flex items-center justify-between">

            <div>
              <p
                className={`text-[11px] font-semibold uppercase tracking-wider ${
                  darkMode
                    ? "text-cyan-400"
                    : "text-cyan-600"
                }`}
              >
                Service Management
              </p>

              <h2 className="mt-0.5 text-xl font-bold tracking-tight">
                {edit
                  ? "Edit Service"
                  : "Add Service"}
              </h2>
            </div>

            <button
              type="button"
              onClick={close}
              disabled={saving}
              className={`flex h-10 w-10 items-center justify-center rounded-full transition active:scale-90 ${
                darkMode
                  ? "bg-white/10 text-white hover:bg-white/15"
                  : "bg-black/[0.06] text-black hover:bg-black/[0.1]"
              }`}
            >
              <X size={19} />
            </button>

          </div>
        </div>

        <form
          onSubmit={save}
          noValidate
          className="max-h-[calc(100vh-110px)] overflow-y-auto px-5 py-5 sm:px-6"
        >

          {/* SERVICE NAME */}

          <IOSField
            label="Service Name"
            darkMode={darkMode}
            error={errors.serviceName}
          >
            <input
              required
              value={form.serviceName}
              maxLength={
                VALIDATION.serviceNameMax
              }
              onChange={(e) =>
                updateField(
                  "serviceName",
                  e.target.value
                )
              }
              placeholder="Enter service name"
              className={iosInput(
                darkMode,
                errors.serviceName
              )}
            />

            <FieldCounter
              value={form.serviceName}
              max={VALIDATION.serviceNameMax}
              darkMode={darkMode}
            />
          </IOSField>

          {/* DESCRIPTION */}

          <IOSField
            label="Description"
            darkMode={darkMode}
            error={errors.description}
          >
            <textarea
              required
              rows={5}
              maxLength={
                VALIDATION.descriptionMax
              }
              value={form.description}
              onChange={(e) =>
                updateField(
                  "description",
                  e.target.value
                )
              }
              placeholder="Enter service description"
              className={`${iosInput(
                darkMode,
                errors.description
              )} min-h-[120px] resize-none py-3.5`}
            />

            <FieldCounter
              value={form.description}
              max={VALIDATION.descriptionMax}
              darkMode={darkMode}
            />
          </IOSField>


          {/* STATUS */}

          <IOSField
            label="Status"
            darkMode={darkMode}
            error={errors.status}
          >
            <div
              className={`flex overflow-hidden rounded-2xl border p-1 ${
                errors.status
                  ? "border-red-500"
                  : darkMode
                  ? "border-white/10 bg-white/[0.05]"
                  : "border-black/[0.06] bg-black/[0.04]"
              }`}
            >

              <button
                type="button"
                onClick={() =>
                  updateField(
                    "status",
                    true
                  )
                }
                className={`h-11 flex-1 rounded-xl text-sm font-semibold transition ${
                  form.status === true
                    ? "bg-cyan-500 text-white shadow-sm"
                    : darkMode
                    ? "text-slate-400"
                    : "text-slate-500"
                }`}
              >
                ACTIVE
              </button>

              <button
                type="button"
                onClick={() =>
                  updateField(
                    "status",
                    false
                  )
                }
                className={`h-11 flex-1 rounded-xl text-sm font-semibold transition ${
                  form.status === false
                    ? "bg-red-500 text-white shadow-sm"
                    : darkMode
                    ? "text-slate-400"
                    : "text-slate-500"
                }`}
              >
                INACTIVE
              </button>

            </div>
          </IOSField>

          {/* ACTIONS */}

          <div className="mt-6 flex gap-3">

            <button
              type="button"
              onClick={close}
              disabled={saving}
              className={`h-12 flex-1 rounded-2xl text-sm font-semibold transition active:scale-[0.98] ${
                darkMode
                  ? "bg-white/10 text-white hover:bg-white/15"
                  : "bg-black/[0.06] text-[#111] hover:bg-black/[0.09]"
              }`}
            >
              Cancel
            </button>

            <button
              type="submit"
              disabled={saving}
              className="h-12 flex-[1.3] rounded-2xl bg-cyan-500 text-sm font-bold text-white shadow-lg shadow-cyan-500/20 transition active:scale-[0.98] disabled:opacity-50"
            >
              {saving
                ? "Saving..."
                : edit
                ? "Update Service"
                : "Save Service"}
            </button>

          </div>

          <div
            style={{
              height:
                "env(safe-area-inset-bottom)",
            }}
          />
        </form>
      </div>
    </div>
  );
}

/* =========================================================
   IOS FIELD
========================================================= */

function IOSField({
  label,
  children,
  darkMode,
  error,
}) {
  return (
    <div className="mb-5">

      <label
        className={`mb-2 block px-1 text-[12px] font-semibold ${
          darkMode
            ? "text-slate-300"
            : "text-slate-600"
        }`}
      >
        {label}
        <span className="ml-1 text-red-500">
          *
        </span>
      </label>

      {children}

      {error && (
        <div className="mt-1.5 flex items-start gap-1.5 px-1">

          <AlertTriangle
            size={13}
            className="mt-[1px] shrink-0 text-red-500"
          />

          <p className="text-[11px] font-medium leading-4 text-red-500">
            {error}
          </p>

        </div>
      )}
    </div>
  );
}

/* =========================================================
   FIELD COUNTER
========================================================= */

function FieldCounter({
  value,
  max,
  darkMode,
}) {
  return (
    <div
      className={`mt-1 flex justify-end px-1 text-[10px] ${
        darkMode
          ? "text-slate-500"
          : "text-slate-400"
      }`}
    >
      {value.length}/{max}
    </div>
  );
}

/* =========================================================
   IOS INPUT
========================================================= */

function iosInput(
  darkMode,
  hasError = false
) {
  return `h-12 w-full rounded-2xl border px-4 text-[15px] font-medium outline-none transition placeholder:text-slate-400 focus:ring-2 ${
    hasError
      ? "border-red-500 focus:border-red-500 focus:ring-red-500/20"
      : darkMode
      ? "border-white/10 bg-white/[0.06] text-white focus:border-cyan-400 focus:ring-cyan-500/20"
      : "border-black/[0.07] bg-white text-[#111] shadow-sm focus:border-cyan-400 focus:ring-cyan-500/20"
  }`;
}

/* =========================================================
   SERVICE CARD
========================================================= */

function ServiceCard({
  service: s,
  onEdit,
  onDelete,
  deletingId,
  darkMode,
}) {
  const active = Boolean(s.status);

  return (
    <article
      className={`flex w-full flex-col overflow-hidden rounded-2xl border ${
        darkMode
          ? "border-slate-700 bg-slate-900"
          : "border-slate-200 bg-white"
      }`}
    >
      <div className="relative aspect-[4/3] w-full bg-slate-100">

        <img
          src={
            s.image ||
            "/assets/wellborn physio.jpg"
          }
          alt={
            s.serviceName ||
            "Service"
          }
          loading="lazy"
          className="h-full w-full object-cover"
          onError={(e) => {
            e.currentTarget.src =
              "/assets/wellborn physio.jpg";
          }}
        />

        <div className="absolute right-3 top-3">
          <StatusBadge
            active={active}
            darkMode={darkMode}
          />
        </div>
      </div>

      <div className="flex flex-1 flex-col px-4 pb-4 pt-2.5">

        <h3
          className={`text-base font-black ${
            darkMode
              ? "text-white"
              : "text-[#001738]"
          }`}
        >
          {s.serviceName ||
            "Unnamed Service"}
        </h3>

        <p
          className={`mt-1.5 text-sm leading-relaxed ${
            darkMode
              ? "text-slate-400"
              : "text-[#5b6e82]"
          }`}
        >
          {s.description ||
            "No description available."}
        </p>

        <div className="mt-auto flex w-full items-center gap-3 pt-5">

          <button
            type="button"
            onClick={() => onEdit(s)}
            className={`flex h-11 flex-1 items-center justify-center gap-2 rounded-xl text-sm font-bold transition active:scale-95 ${
              darkMode
                ? "bg-slate-800 text-white hover:bg-slate-700"
                : "bg-[#f1f4f9] text-[#001738] hover:bg-slate-200"
            }`}
          >
            <Pencil size={15} />
            Edit
          </button>

          <button
            type="button"
            onClick={() => onDelete(s)}
            disabled={
              deletingId ===
              s.serviceId
            }
            className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-xl border ${
              darkMode
                ? "border-red-500/30 bg-red-500/10 text-red-400"
                : "border-red-200 bg-[#fff5f5] text-[#e03131]"
            }`}
          >
            {deletingId ===
            s.serviceId ? (
              <span className="h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent" />
            ) : (
              <Trash2 size={18} />
            )}
          </button>

        </div>
      </div>
    </article>
  );
}

/* =========================================================
   STATUS
========================================================= */

function StatusBadge({
  active,
  darkMode,
}) {
  return active ? (
    <span
      className={`inline-flex items-center gap-1 rounded-full border px-2.5 py-1 text-[10px] font-bold ${
        darkMode
          ? "border-emerald-500/50 bg-slate-900/80 text-emerald-400"
          : "border-emerald-200 bg-white/95 text-[#0ca678]"
      }`}
    >
      <CheckCircle2 size={12} />
      ACTIVE
    </span>
  ) : (
    <span
      className={`inline-flex items-center gap-1 rounded-full border px-2.5 py-1 text-[10px] font-bold ${
        darkMode
          ? "border-red-500/50 bg-slate-900/80 text-red-400"
          : "border-red-200 bg-white/95 text-[#e03131]"
      }`}
    >
      <XCircle size={12} />
      INACTIVE
    </span>
  );
}

/* =========================================================
   DELETE MODAL
========================================================= */

function DeleteModal({
  service,
  close,
  confirm,
  deleting,
  darkMode,
}) {
  return (
    <div className="fixed inset-0 z-[10000] flex items-center justify-center bg-black/50 p-4 backdrop-blur-xl">

      <div
        className={`w-full max-w-sm rounded-[28px] border p-6 shadow-2xl ${
          darkMode
            ? "border-white/10 bg-[#17181c]"
            : "border-white bg-[#f7f7f9]"
        }`}
      >

        <div className="mb-4 flex justify-center">
          <div className="flex h-16 w-16 items-center justify-center rounded-full bg-red-100 text-red-600">
            <AlertTriangle size={30} />
          </div>
        </div>

        <div className="text-center">

          <h3 className="text-xl font-black">
            Delete Service?
          </h3>

          <p className="mt-2 text-sm text-slate-500">
            Are you sure you want to delete{" "}
            <span
              className={`font-bold ${
                darkMode
                  ? "text-white"
                  : "text-slate-900"
              }`}
            >
              "{service.serviceName}"
            </span>
            ?
          </p>
        </div>

        <div className="mt-6 flex gap-3">

          <button
            onClick={close}
            disabled={deleting}
            className="h-12 flex-1 rounded-2xl bg-slate-100 text-sm font-bold text-slate-900"
          >
            Cancel
          </button>

          <button
            onClick={confirm}
            disabled={deleting}
            className="flex h-12 flex-1 items-center justify-center gap-2 rounded-2xl bg-red-600 text-sm font-bold text-white"
          >
            {deleting ? (
              <span className="h-5 w-5 animate-spin rounded-full border-2 border-white border-t-transparent" />
            ) : (
              <>
                <Trash2 size={18} />
                Delete
              </>
            )}
          </button>

        </div>
      </div>
    </div>
  );
}

/* =========================================================
   EMPTY
========================================================= */

function EmptyState({
  darkMode,
}) {
  return (
    <div
      className={`flex min-h-[300px] w-full flex-col items-center justify-center rounded-3xl border border-dashed p-6 text-center ${
        darkMode
          ? "border-slate-700 bg-slate-900"
          : "border-slate-300 bg-white"
      }`}
    >
      <div
        className={`mb-4 flex h-16 w-16 items-center justify-center rounded-full ${
          darkMode
            ? "bg-slate-800 text-slate-400"
            : "bg-slate-100 text-slate-500"
        }`}
      >
        <Layers size={28} />
      </div>

      <h3 className="text-lg font-black">
        No services found
      </h3>

      <p className="mt-1 text-sm text-slate-500">
        Add a new service to get started.
      </p>
    </div>
  );
}

/* =========================================================
   LOADING
========================================================= */

function LoadingCards({
  darkMode,
}) {
  return (
    <div className="grid w-full grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
      {[1, 2, 3, 4].map(
        (item) => (
          <div
            key={item}
            className={`h-[350px] animate-pulse rounded-3xl border ${
              darkMode
                ? "border-slate-700 bg-slate-900"
                : "border-slate-200 bg-white"
            }`}
          />
        )
      )}
    </div>
  );
}