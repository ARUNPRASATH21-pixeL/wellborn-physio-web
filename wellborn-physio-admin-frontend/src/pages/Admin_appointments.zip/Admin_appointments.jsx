import React, { useEffect, useState } from "react";

import {
  API,
  getData,
  putData,
  deleteData,
} from "../services/api";

import {
  Search,
  Trash2,
  CalendarDays,
  Clock3,
  UserRound,
  Phone,
  Mail,
  Stethoscope,
  Layers,
  MessageSquareText,
  ClipboardList,
  Activity,
  X,
  CheckCircle2,
  AlertTriangle,
  Loader2,
  Check,
  Ban,
} from "lucide-react";

/*
=========================================================
 WELLBORN PHYSIO
 ADMIN APPOINTMENTS

 FEATURES
 --------------------------------------------------------
 ✓ Mobile responsive
 ✓ Tablet responsive
 ✓ Desktop table
 ✓ Delete confirmation modal
 ✓ APPROVED confirmation modal
 ✓ REJECTED confirmation modal
 ✓ Success popup
 ✓ Error popup
 ✓ Dark mode
 ✓ Search
 ✓ Delete
 ✓ Status update
 ✓ Status update confirmation
 ✓ No browser alert()
 ✓ Modal above navbar
 ✓ Centered modal
 ✓ appointmentTime NOT sent during update
 ✓ doctorId NOT sent during update
=========================================================
*/

export default function Admin_appointments() {
  const [rows, setRows] = useState([]);
  const [q, setQ] = useState("");

  const [loading, setLoading] = useState(true);

  const [deletingId, setDeletingId] = useState(null);
  const [updatingId, setUpdatingId] = useState(null);

  /*
  ========================================================
  DELETE MODAL
  ========================================================
  */

  const [deleteModal, setDeleteModal] = useState({
    open: false,
    appointment: null,
  });

  /*
  ========================================================
  STATUS CONFIRMATION MODAL
  ========================================================
  */

  const [statusModal, setStatusModal] = useState({
    open: false,
    appointment: null,
    newStatus: "",
  });

  /*
  ========================================================
  SUCCESS POPUP
  ========================================================
  */

  const [successPopup, setSuccessPopup] = useState({
    open: false,
    title: "",
    message: "",
  });

  /*
  ========================================================
  ERROR POPUP
  ========================================================
  */

  const [errorPopup, setErrorPopup] = useState({
    open: false,
    title: "",
    message: "",
  });

  /*
  ========================================================
  DARK MODE
  ========================================================
  */

  const [darkMode, setDarkMode] = useState(() => {
    try {
      return document.documentElement.classList.contains(
        "wellborn-admin-dark"
      );
    } catch {
      return false;
    }
  });

  useEffect(() => {
    const root = document.documentElement;

    const updateTheme = () => {
      setDarkMode(
        root.classList.contains("wellborn-admin-dark")
      );
    };

    updateTheme();

    const observer = new MutationObserver(() => {
      updateTheme();
    });

    observer.observe(root, {
      attributes: true,
      attributeFilter: ["class"],
    });

    return () => observer.disconnect();
  }, []);

  /*
  ========================================================
  AUTO CLOSE SUCCESS POPUP
  ========================================================
  */

  useEffect(() => {
    if (!successPopup.open) return;

    const timer = setTimeout(() => {
      setSuccessPopup({
        open: false,
        title: "",
        message: "",
      });
    }, 2600);

    return () => clearTimeout(timer);
  }, [successPopup.open]);

  /*
  ========================================================
  AUTO CLOSE ERROR POPUP
  ========================================================
  */

  useEffect(() => {
    if (!errorPopup.open) return;

    const timer = setTimeout(() => {
      setErrorPopup({
        open: false,
        title: "",
        message: "",
      });
    }, 3500);

    return () => clearTimeout(timer);
  }, [errorPopup.open]);

  /*
  ========================================================
  LOAD APPOINTMENTS
  ========================================================
  */

  const load = async () => {
    setLoading(true);

    const startTime = Date.now();

    try {
      const response = await getData(
        API.APPOINTMENT_GET_ALL
      );

      setRows(
        Array.isArray(response)
          ? response
          : []
      );
    } catch (error) {
      console.error(
        "Appointments loading error:",
        error
      );

      setRows([]);

      showError(
        "Loading Failed",
        error?.message ||
          "Unable to load appointments."
      );
    } finally {
      const elapsed =
        Date.now() - startTime;

      const remainingTime = Math.max(
        0,
        1200 - elapsed
      );

      setTimeout(() => {
        setLoading(false);
      }, remainingTime);
    }
  };

  useEffect(() => {
    load();
  }, []);

  /*
  ========================================================
  SUCCESS HELPER
  ========================================================
  */

  const showSuccess = (
    title,
    message
  ) => {
    setSuccessPopup({
      open: true,
      title,
      message,
    });
  };

  /*
  ========================================================
  ERROR HELPER
  ========================================================
  */

  const showError = (
    title,
    message
  ) => {
    setErrorPopup({
      open: true,
      title,
      message,
    });
  };

  /*
  ========================================================
  OPEN STATUS CONFIRMATION

  APPROVED / REJECTED மட்டும் confirmation.
  மற்ற status direct update.
  ========================================================
  */

  const handleStatusChange = (
    appointment,
    value
  ) => {
    if (
      value === "APPROVED" ||
      value === "REJECTED"
    ) {
      setStatusModal({
        open: true,
        appointment,
        newStatus: value,
      });

      return;
    }

    updateStatus(
      appointment,
      value
    );
  };

  /*
  ========================================================
  CLOSE STATUS MODAL
  ========================================================
  */

  const closeStatusModal = () => {
    if (updatingId !== null) return;

    setStatusModal({
      open: false,
      appointment: null,
      newStatus: "",
    });
  };

  /*
  ========================================================
  CONFIRM STATUS CHANGE
  ========================================================
  */

  const confirmStatusChange = async () => {
    const appointment =
      statusModal.appointment;

    const newStatus =
      statusModal.newStatus;

    if (!appointment || !newStatus) {
      return;
    }

    await updateStatus(
      appointment,
      newStatus
    );

    setStatusModal({
      open: false,
      appointment: null,
      newStatus: "",
    });
  };

  /*
  ========================================================
  UPDATE STATUS

  IMPORTANT:
  appointmentTime NOT SENT
  doctorId NOT SENT
  ========================================================
  */

  const updateStatus = async (
    appointment,
    value
  ) => {
    try {
      setUpdatingId(
        appointment.appointmentId
      );

      await putData(
        `${API.APPOINTMENT_UPDATE}/${appointment.appointmentId}`,
        {
          patientName:
            appointment.patientName,

          phone:
            appointment.phone,

          email:
            appointment.email,

          appointmentDate:
            appointment.appointmentDate,

          message:
            appointment.message,

          serviceId:
            appointment.serviceId,

          status: value,
        }
      );

      setRows((previous) =>
        previous.map((item) =>
          item.appointmentId ===
          appointment.appointmentId
            ? {
                ...item,
                status: value,
              }
            : item
        )
      );

      const successText =
        value === "APPROVED"
          ? "Appointment approved successfully."
          : value === "REJECTED"
          ? "Appointment rejected successfully."
          : `Appointment status changed to ${value}.`;

      showSuccess(
        "Status Updated",
        successText
      );
    } catch (error) {
      console.error(
        "Status update error:",
        error
      );

      showError(
        "Update Failed",
        error?.message ||
          "Unable to update appointment status."
      );
    } finally {
      setUpdatingId(null);
    }
  };

  /*
  ========================================================
  OPEN DELETE MODAL
  ========================================================
  */

  const openDeleteModal = (
    appointment
  ) => {
    setDeleteModal({
      open: true,
      appointment,
    });
  };

  /*
  ========================================================
  CLOSE DELETE MODAL
  ========================================================
  */

  const closeDeleteModal = () => {
    if (deletingId !== null) return;

    setDeleteModal({
      open: false,
      appointment: null,
    });
  };

  /*
  ========================================================
  CONFIRM DELETE
  ========================================================
  */

  const confirmDelete = async () => {
    const appointment =
      deleteModal.appointment;

    if (!appointment) return;

    const id =
      appointment.appointmentId;

    try {
      setDeletingId(id);

      await deleteData(
        `${API.APPOINTMENT_DELETE}/${id}`
      );

      setRows((previous) =>
        previous.filter(
          (item) =>
            item.appointmentId !== id
        )
      );

      setDeleteModal({
        open: false,
        appointment: null,
      });

      showSuccess(
        "Appointment Deleted",
        `${
          appointment.patientName ||
          "Appointment"
        } has been deleted successfully.`
      );
    } catch (error) {
      console.error(
        "Delete appointment error:",
        error
      );

      showError(
        "Delete Failed",
        error?.message ||
          "Unable to delete appointment."
      );
    } finally {
      setDeletingId(null);
    }
  };

  /*
  ========================================================
  SEARCH
  ========================================================
  */

  const searchText =
    q.trim().toLowerCase();

  const filteredAppointments =
    rows.filter((item) => {
      if (!searchText) return true;

      return JSON.stringify(item)
        .toLowerCase()
        .includes(searchText);
    });

  /*
  ========================================================
  UI
  ========================================================
  */

  return (
    <>
      <div
        className={`
          min-h-screen
          w-full
          min-w-0
          max-w-full
          overflow-x-hidden
          transition-colors
          duration-300

          ${
            darkMode
              ? "bg-slate-950 text-slate-100"
              : "bg-slate-50 text-slate-900"
          }
        `}
      >
        <main
          className="
            relative
            z-10
            mx-auto
            w-full
            max-w-[1500px]
            min-w-0
            overflow-hidden

            pt-[88px]
            px-3
            pb-8

            min-[380px]:pt-[92px]
            min-[380px]:px-4

            sm:pt-[96px]
            sm:px-6
            sm:pb-10

            lg:pt-[105px]
            lg:px-8
          "
        >
          {/* HEADER */}

          <section
            className={`
              mb-4
              w-full
              min-w-0
              max-w-full
              overflow-hidden

              rounded-2xl
              border
              p-3

              min-[380px]:p-4

              sm:mb-6
              sm:p-6

              ${
                darkMode
                  ? `
                    border-slate-700
                    bg-slate-900
                    shadow-lg
                    shadow-black/20
                  `
                  : `
                    border-slate-200
                    bg-white
                    shadow-md
                    shadow-slate-200/50
                  `
              }
            `}
          >
            <div
              className="
                flex
                w-full
                min-w-0
                max-w-full
                items-center
                gap-2.5
                sm:gap-4
              "
            >
              <div
                className={`
                  flex
                  h-10
                  w-10
                  shrink-0
                  items-center
                  justify-center
                  rounded-xl
                  border

                  min-[380px]:h-11
                  min-[380px]:w-11

                  sm:h-14
                  sm:w-14
                  sm:rounded-2xl

                  ${
                    darkMode
                      ? `
                        border-cyan-400/30
                        bg-cyan-500/10
                        text-cyan-300
                      `
                      : `
                        border-cyan-100
                        bg-cyan-50
                        text-cyan-600
                      `
                  }
                `}
              >
                <ClipboardList
                  size={19}
                  className="sm:hidden"
                />

                <ClipboardList
                  size={25}
                  className="hidden sm:block"
                />
              </div>

              <div
                className="
                  min-w-0
                  max-w-full
                  flex-1
                  overflow-hidden
                "
              >
                <div
                  className="
                    mb-0.5
                    flex
                    min-w-0
                    items-center
                    gap-1.5
                  "
                >
                  <span
                    className="
                      h-1.5
                      w-1.5
                      shrink-0
                      rounded-full
                      bg-emerald-500
                      animate-pulse
                    "
                  />

                  <span
                    className={`
                      min-w-0
                      max-w-full
                      truncate
                      text-[7px]
                      font-bold
                      uppercase
                      tracking-wider

                      min-[380px]:text-[8px]
                      sm:text-[10px]

                      ${
                        darkMode
                          ? "text-emerald-300"
                          : "text-emerald-600"
                      }
                    `}
                  >
                    Admin Control Center
                  </span>
                </div>

                <h1
                  className={`
                    min-w-0
                    max-w-full
                    truncate
                    text-base
                    font-black
                    leading-tight

                    min-[380px]:text-lg
                    sm:text-2xl
                    lg:text-3xl

                    ${
                      darkMode
                        ? "text-white"
                        : "text-slate-900"
                    }
                  `}
                >
                  Appointments
                </h1>

                <p
                  className={`
                    mt-0.5
                    min-w-0
                    max-w-full
                    truncate
                    text-[8px]

                    min-[380px]:text-[9px]
                    sm:text-xs

                    ${
                      darkMode
                        ? "text-slate-400"
                        : "text-slate-500"
                    }
                  `}
                >
                  Manage patient appointments
                  and appointment status
                </p>
              </div>
            </div>
          </section>

          {/* SECTION TITLE */}

          <div
            className="
              mb-2.5
              flex
              w-full
              min-w-0
              items-center
              gap-1.5
              overflow-hidden
              px-0.5
              sm:mb-4
              sm:gap-2
            "
          >
            <div
              className={`
                flex
                h-6
                w-6
                shrink-0
                items-center
                justify-center
                rounded-md
                border

                min-[380px]:h-7
                min-[380px]:w-7

                sm:h-8
                sm:w-8
                sm:rounded-lg

                ${
                  darkMode
                    ? `
                      border-cyan-400/30
                      bg-cyan-500/10
                      text-cyan-300
                    `
                    : `
                      border-cyan-100
                      bg-cyan-50
                      text-cyan-600
                    `
                }
              `}
            >
              <Activity
                size={12}
                strokeWidth={2.5}
              />
            </div>

            <h2
              className={`
                m-0
                min-w-0
                flex-1
                break-words
                text-xs
                font-extrabold

                min-[380px]:text-sm
                sm:text-base

                ${
                  darkMode
                    ? "text-slate-100"
                    : "text-slate-800"
                }
              `}
            >
              Appointment overview
            </h2>
          </div>

          {/* SEARCH */}

          <div
            className="
              mb-4
              grid
              w-full
              min-w-0
              grid-cols-1
              gap-2.5
              sm:grid-cols-[1fr_auto]
              sm:items-center
            "
          >
            <div
              className="
                relative
                w-full
                min-w-0
              "
            >
              <Search
                size={17}
                className="
                  pointer-events-none
                  absolute
                  left-3
                  top-1/2
                  -translate-y-1/2
                  text-slate-400
                "
              />

              <input
                type="text"
                value={q}
                onChange={(e) =>
                  setQ(e.target.value)
                }
                placeholder="Search appointments..."
                className={`
                  h-11
                  w-full
                  min-w-0
                  rounded-xl
                  border
                  pl-9
                  pr-4
                  text-xs
                  font-semibold
                  outline-none
                  transition

                  ${
                    darkMode
                      ? `
                        border-slate-700
                        bg-slate-900
                        text-white
                        placeholder:text-slate-500
                        focus:border-cyan-400
                        focus:ring-2
                        focus:ring-cyan-500/20
                      `
                      : `
                        border-slate-200
                        bg-white
                        text-slate-900
                        placeholder:text-slate-400
                        focus:border-cyan-400
                        focus:ring-2
                        focus:ring-cyan-100
                      `
                  }
                `}
              />
            </div>

            <div
              className={`
                flex
                w-fit
                max-w-full
                shrink-0
                items-center
                gap-1.5
                rounded-lg
                border
                px-2.5
                py-1.5
                text-[9px]
                font-bold

                ${
                  darkMode
                    ? `
                      border-slate-700
                      bg-slate-900
                      text-slate-200
                    `
                    : `
                      border-slate-200
                      bg-white
                      text-slate-600
                    `
                }
              `}
            >
              <CalendarDays
                size={12}
                className={
                  darkMode
                    ? "text-cyan-300"
                    : "text-cyan-600"
                }
              />

              {filteredAppointments.length}

              {" appointment"}

              {filteredAppointments.length !== 1
                ? "s"
                : ""}
            </div>
          </div>

          {/* MOBILE + TABLET */}

          <div
            className="
              w-full
              min-w-0
              max-w-full
              space-y-3
              lg:hidden
            "
          >
            {loading ? (
              <LoadingCards
                darkMode={darkMode}
              />
            ) : filteredAppointments.length ===
              0 ? (
              <EmptyState
                darkMode={darkMode}
              />
            ) : (
              filteredAppointments.map(
                (appointment) => (
                  <AppointmentCard
                    key={
                      appointment.appointmentId
                    }
                    appointment={
                      appointment
                    }
                    onStatus={
                      handleStatusChange
                    }
                    onDelete={
                      openDeleteModal
                    }
                    updatingId={
                      updatingId
                    }
                    deletingId={
                      deletingId
                    }
                    darkMode={
                      darkMode
                    }
                  />
                )
              )
            )}
          </div>

          {/* DESKTOP TABLE */}

          <div
            className={`
              hidden
              max-w-full
              overflow-hidden
              rounded-2xl
              border
              shadow-sm
              lg:block

              ${
                darkMode
                  ? `
                    border-slate-700
                    bg-slate-900
                    shadow-black/20
                  `
                  : `
                    border-slate-200
                    bg-white
                  `
              }
            `}
          >
            <div className="overflow-x-auto">
              <table
                className="
                  w-full
                  min-w-[950px]
                  text-sm
                "
              >
                <thead>
                  <tr
                    className={`
                      border-b
                      text-left
                      text-xs
                      font-bold

                      ${
                        darkMode
                          ? `
                            border-slate-700
                            bg-slate-800
                            text-white
                          `
                          : `
                            border-slate-200
                            bg-slate-50
                            text-slate-700
                          `
                      }
                    `}
                  >
                    <th className="px-5 py-4">
                      Patient
                    </th>

                    <th className="px-4 py-4">
                      Doctor
                    </th>

                    <th className="px-4 py-4">
                      Service
                    </th>

                    <th className="px-4 py-4">
                      Date
                    </th>

                    <th className="px-4 py-4">
                      Time
                    </th>

                    <th className="px-4 py-4">
                      Status
                    </th>

                    <th className="px-4 py-4 text-center">
                      Action
                    </th>
                  </tr>
                </thead>

                <tbody>
                  {loading ? (
                    <DesktopLoading
                      darkMode={darkMode}
                    />
                  ) : filteredAppointments.length ===
                    0 ? (
                    <tr>
                      <td colSpan="7">
                        <EmptyState
                          darkMode={
                            darkMode
                          }
                        />
                      </td>
                    </tr>
                  ) : (
                    filteredAppointments.map(
                      (appointment) => (
                        <DesktopRow
                          key={
                            appointment.appointmentId
                          }
                          appointment={
                            appointment
                          }
                          onStatus={
                            handleStatusChange
                          }
                          onDelete={
                            openDeleteModal
                          }
                          updatingId={
                            updatingId
                          }
                          deletingId={
                            deletingId
                          }
                          darkMode={
                            darkMode
                          }
                        />
                      )
                    )
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </main>
      </div>

      {/* DELETE MODAL */}

      {deleteModal.open && (
        <DeleteConfirmationModal
          appointment={
            deleteModal.appointment
          }
          darkMode={darkMode}
          deleting={
            deletingId !== null
          }
          onCancel={
            closeDeleteModal
          }
          onConfirm={
            confirmDelete
          }
        />
      )}

      {/* STATUS MODAL */}

      {statusModal.open && (
        <StatusConfirmationModal
          appointment={
            statusModal.appointment
          }
          newStatus={
            statusModal.newStatus
          }
          darkMode={darkMode}
          updating={
            updatingId !== null
          }
          onCancel={
            closeStatusModal
          }
          onConfirm={
            confirmStatusChange
          }
        />
      )}

      {/* SUCCESS */}

      {successPopup.open && (
        <SuccessPopup
          title={
            successPopup.title
          }
          message={
            successPopup.message
          }
          darkMode={darkMode}
          onClose={() =>
            setSuccessPopup({
              open: false,
              title: "",
              message: "",
            })
          }
        />
      )}

      {/* ERROR */}

      {errorPopup.open && (
        <ErrorPopup
          title={
            errorPopup.title
          }
          message={
            errorPopup.message
          }
          darkMode={darkMode}
          onClose={() =>
            setErrorPopup({
              open: false,
              title: "",
              message: "",
            })
          }
        />
      )}
    </>
  );
}

/* =========================================================
   STATUS CONFIRMATION MODAL
========================================================= */

function StatusConfirmationModal({
  appointment,
  newStatus,
  darkMode,
  updating,
  onCancel,
  onConfirm,
}) {
  const approved =
    newStatus === "APPROVED";

  const rejected =
    newStatus === "REJECTED";

  return (
    <div
      className="
        fixed
        inset-0
        z-[99999]

        flex
        min-h-screen
        items-center
        justify-center

        bg-black/70
        px-4
        py-6

        backdrop-blur-md
      "
      onMouseDown={(e) => {
        if (
          e.target === e.currentTarget &&
          !updating
        ) {
          onCancel();
        }
      }}
    >
      <div
        className={`
          relative
          w-full
          max-w-[430px]
          overflow-hidden
          rounded-3xl
          border
          shadow-2xl

          animate-[statusModalIn_0.22s_ease-out]

          ${
            darkMode
              ? `
                border-slate-700
                bg-slate-900
                shadow-black/60
              `
              : `
                border-slate-200
                bg-white
                shadow-black/30
              `
          }
        `}
      >
        {/* TOP LINE */}

        <div
          className={`
            h-1
            w-full

            ${
              approved
                ? "bg-gradient-to-r from-emerald-400 via-green-500 to-emerald-600"
                : "bg-gradient-to-r from-red-400 via-red-500 to-rose-600"
            }
          `}
        />

        {/* CLOSE */}

        <button
          type="button"
          onClick={onCancel}
          disabled={updating}
          className={`
            absolute
            right-3
            top-4
            flex
            h-8
            w-8
            items-center
            justify-center
            rounded-full
            transition

            disabled:pointer-events-none
            disabled:opacity-40

            ${
              darkMode
                ? `
                  text-slate-400
                  hover:bg-slate-800
                  hover:text-white
                `
                : `
                  text-slate-400
                  hover:bg-slate-100
                  hover:text-slate-800
                `
            }
          `}
        >
          <X size={17} />
        </button>

        <div className="px-5 pb-5 pt-7 sm:px-7 sm:pb-7">

          {/* ICON */}

          <div className="mb-5 flex justify-center">
            <div
              className={`
                flex
                h-16
                w-16
                items-center
                justify-center
                rounded-2xl
                border
                shadow-lg

                ${
                  approved
                    ? `
                      border-emerald-200
                      bg-emerald-50
                      text-emerald-600
                      dark:border-emerald-400/30
                      dark:bg-emerald-500/10
                      dark:text-emerald-300
                    `
                    : `
                      border-red-200
                      bg-red-50
                      text-red-600
                      dark:border-red-400/30
                      dark:bg-red-500/10
                      dark:text-red-300
                    `
                }
              `}
            >
              {approved ? (
                <Check
                  size={31}
                  strokeWidth={3}
                />
              ) : (
                <Ban
                  size={30}
                  strokeWidth={2.2}
                />
              )}
            </div>
          </div>

          {/* TITLE */}

          <div className="text-center">
            <h2
              className={`
                text-lg
                font-black
                sm:text-xl

                ${
                  darkMode
                    ? "text-white"
                    : "text-slate-900"
                }
              `}
            >
              {approved
                ? "Approve Appointment?"
                : "Reject Appointment?"}
            </h2>

            <p
              className={`
                mx-auto
                mt-2
                max-w-[340px]
                text-xs
                leading-relaxed
                sm:text-sm

                ${
                  darkMode
                    ? "text-slate-400"
                    : "text-slate-500"
                }
              `}
            >
              {approved
                ? "Are you sure you want to approve this appointment?"
                : "Are you sure you want to reject this appointment?"}
            </p>
          </div>

          {/* PATIENT INFO */}

          <div
            className={`
              mt-5
              rounded-2xl
              border
              p-3.5

              ${
                darkMode
                  ? `
                    border-slate-700
                    bg-slate-950
                  `
                  : `
                    border-slate-200
                    bg-slate-50
                  `
              }
            `}
          >
            <div className="flex min-w-0 items-center gap-3">

              <div
                className={`
                  flex
                  h-10
                  w-10
                  shrink-0
                  items-center
                  justify-center
                  rounded-xl

                  ${
                    approved
                      ? `
                        bg-emerald-500/10
                        text-emerald-600
                        dark:text-emerald-300
                      `
                      : `
                        bg-red-500/10
                        text-red-600
                        dark:text-red-300
                      `
                  }
                `}
              >
                <UserRound size={18} />
              </div>

              <div className="min-w-0 flex-1">
                <p
                  className={`
                    truncate
                    text-sm
                    font-black

                    ${
                      darkMode
                        ? "text-white"
                        : "text-slate-900"
                    }
                  `}
                >
                  {appointment?.patientName ||
                    "Unknown Patient"}
                </p>

                <p
                  className={`
                    mt-0.5
                    truncate
                    text-[10px]

                    ${
                      darkMode
                        ? "text-slate-400"
                        : "text-slate-500"
                    }
                  `}
                >
                  Appointment #
                  {
                    appointment?.appointmentId
                  }
                </p>
              </div>
            </div>

            <div className="mt-3 grid grid-cols-2 gap-2">

              <div
                className={`
                  rounded-xl
                  border
                  p-2.5

                  ${
                    darkMode
                      ? `
                        border-slate-700
                        bg-slate-900
                      `
                      : `
                        border-slate-200
                        bg-white
                      `
                  }
                `}
              >
                <p className="text-[8px] font-bold uppercase text-slate-400">
                  Date
                </p>

                <p
                  className={`
                    mt-1
                    truncate
                    text-[10px]
                    font-bold

                    ${
                      darkMode
                        ? "text-white"
                        : "text-slate-800"
                    }
                  `}
                >
                  {appointment?.appointmentDate ||
                    "—"}
                </p>
              </div>

              <div
                className={`
                  rounded-xl
                  border
                  p-2.5

                  ${
                    darkMode
                      ? `
                        border-slate-700
                        bg-slate-900
                      `
                      : `
                        border-slate-200
                        bg-white
                      `
                  }
                `}
              >
                <p className="text-[8px] font-bold uppercase text-slate-400">
                  Time
                </p>

                <p
                  className={`
                    mt-1
                    truncate
                    text-[10px]
                    font-bold

                    ${
                      darkMode
                        ? "text-white"
                        : "text-slate-800"
                    }
                  `}
                >
                  {appointment?.appointmentTime ||
                    "—"}
                </p>
              </div>
            </div>

            {/* NEW STATUS */}

            <div
              className={`
                mt-2
                flex
                items-center
                justify-between
                rounded-xl
                border
                px-3
                py-2.5

                ${
                  approved
                    ? `
                      border-emerald-200
                      bg-emerald-50
                      dark:border-emerald-400/20
                      dark:bg-emerald-500/10
                    `
                    : `
                      border-red-200
                      bg-red-50
                      dark:border-red-400/20
                      dark:bg-red-500/10
                    `
                }
              `}
            >
              <span
                className={`
                  text-[9px]
                  font-bold
                  uppercase

                  ${
                    approved
                      ? `
                        text-emerald-700
                        dark:text-emerald-300
                      `
                      : `
                        text-red-700
                        dark:text-red-300
                      `
                  }
                `}
              >
                New Status
              </span>

              <span
                className={`
                  rounded-lg
                  px-2
                  py-1
                  text-[9px]
                  font-black

                  ${
                    approved
                      ? `
                        bg-emerald-500
                        text-white
                      `
                      : `
                        bg-red-500
                        text-white
                      `
                  }
                `}
              >
                {newStatus}
              </span>
            </div>
          </div>

          {/* BUTTONS */}

          <div className="mt-5 grid grid-cols-2 gap-2.5">

            <button
              type="button"
              onClick={onCancel}
              disabled={updating}
              className={`
                h-11
                rounded-xl
                border
                text-xs
                font-black
                transition
                active:scale-[0.98]
                disabled:opacity-50

                ${
                  darkMode
                    ? `
                      border-slate-700
                      bg-slate-800
                      text-slate-200
                      hover:bg-slate-700
                    `
                    : `
                      border-slate-200
                      bg-white
                      text-slate-700
                      hover:bg-slate-50
                    `
                }
              `}
            >
              Cancel
            </button>

            <button
              type="button"
              onClick={onConfirm}
              disabled={updating}
              className={`
                flex
                h-11
                items-center
                justify-center
                gap-2
                rounded-xl
                text-xs
                font-black
                text-white
                shadow-lg
                transition
                active:scale-[0.98]
                disabled:cursor-not-allowed
                disabled:opacity-60

                ${
                  approved
                    ? `
                      bg-emerald-600
                      shadow-emerald-500/20
                      hover:bg-emerald-700
                    `
                    : `
                      bg-red-600
                      shadow-red-500/20
                      hover:bg-red-700
                    `
                }
              `}
            >
              {updating ? (
                <>
                  <Loader2
                    size={15}
                    className="animate-spin"
                  />

                  Updating...
                </>
              ) : (
                <>
                  {approved ? (
                    <Check size={15} />
                  ) : (
                    <Ban size={15} />
                  )}

                  {approved
                    ? "Approve"
                    : "Reject"}
                </>
              )}
            </button>
          </div>
        </div>
      </div>

      <style>
        {`
          @keyframes statusModalIn {
            from {
              opacity: 0;
              transform: translateY(14px) scale(0.96);
            }

            to {
              opacity: 1;
              transform: translateY(0) scale(1);
            }
          }
        `}
      </style>
    </div>
  );
}

/* =========================================================
   DELETE CONFIRMATION MODAL
========================================================= */

function DeleteConfirmationModal({
  appointment,
  darkMode,
  deleting,
  onCancel,
  onConfirm,
}) {
  return (
    <div
      className="
        fixed
        inset-0
        z-[99999]
        flex
        min-h-screen
        items-center
        justify-center
        bg-black/70
        px-4
        py-6
        backdrop-blur-md
      "
      onMouseDown={(e) => {
        if (
          e.target === e.currentTarget &&
          !deleting
        ) {
          onCancel();
        }
      }}
    >
      <div
        className={`
          relative
          w-full
          max-w-[430px]
          overflow-hidden
          rounded-3xl
          border
          shadow-2xl
          animate-[modalIn_0.22s_ease-out]

          ${
            darkMode
              ? `
                border-slate-700
                bg-slate-900
                shadow-black/60
              `
              : `
                border-slate-200
                bg-white
                shadow-black/30
              `
          }
        `}
      >
        <div
          className="
            h-1
            w-full
            bg-gradient-to-r
            from-red-500
            via-orange-500
            to-red-600
          "
        />

        <button
          type="button"
          onClick={onCancel}
          disabled={deleting}
          className={`
            absolute
            right-3
            top-4
            flex
            h-8
            w-8
            items-center
            justify-center
            rounded-full
            transition
            disabled:pointer-events-none
            disabled:opacity-40

            ${
              darkMode
                ? `
                  text-slate-400
                  hover:bg-slate-800
                  hover:text-white
                `
                : `
                  text-slate-400
                  hover:bg-slate-100
                  hover:text-slate-800
                `
            }
          `}
        >
          <X size={17} />
        </button>

        <div className="px-5 pb-5 pt-7 sm:px-7 sm:pb-7">

          <div className="mb-5 flex justify-center">
            <div
              className={`
                flex
                h-16
                w-16
                items-center
                justify-center
                rounded-2xl
                border
                shadow-lg

                ${
                  darkMode
                    ? `
                      border-red-400/30
                      bg-red-500/10
                      text-red-300
                    `
                    : `
                      border-red-100
                      bg-red-50
                      text-red-600
                    `
                }
              `}
            >
              <AlertTriangle
                size={30}
              />
            </div>
          </div>

          <div className="text-center">
            <h2
              className={`
                text-lg
                font-black
                sm:text-xl

                ${
                  darkMode
                    ? "text-white"
                    : "text-slate-900"
                }
              `}
            >
              Delete Appointment?
            </h2>

            <p
              className={`
                mx-auto
                mt-2
                max-w-[330px]
                text-xs
                leading-relaxed
                sm:text-sm

                ${
                  darkMode
                    ? "text-slate-400"
                    : "text-slate-500"
                }
              `}
            >
              Are you sure you want to
              permanently delete this
              appointment?
            </p>
          </div>

          <div
            className={`
              mt-5
              rounded-2xl
              border
              p-3.5

              ${
                darkMode
                  ? `
                    border-slate-700
                    bg-slate-950
                  `
                  : `
                    border-slate-200
                    bg-slate-50
                  `
              }
            `}
          >
            <div className="flex min-w-0 items-center gap-3">
              <div
                className={`
                  flex
                  h-10
                  w-10
                  shrink-0
                  items-center
                  justify-center
                  rounded-xl

                  ${
                    darkMode
                      ? `
                        bg-cyan-500/10
                        text-cyan-300
                      `
                      : `
                        bg-cyan-50
                        text-cyan-600
                      `
                  }
                `}
              >
                <UserRound size={18} />
              </div>

              <div className="min-w-0 flex-1">
                <p
                  className={`
                    truncate
                    text-sm
                    font-black

                    ${
                      darkMode
                        ? "text-white"
                        : "text-slate-900"
                    }
                  `}
                >
                  {appointment?.patientName ||
                    "Unknown Patient"}
                </p>

                <p
                  className={`
                    mt-0.5
                    truncate
                    text-[10px]

                    ${
                      darkMode
                        ? "text-slate-400"
                        : "text-slate-500"
                    }
                  `}
                >
                  Appointment #
                  {
                    appointment?.appointmentId
                  }
                </p>
              </div>
            </div>

            <div className="mt-3 grid grid-cols-2 gap-2">

              <div
                className={`
                  rounded-xl
                  border
                  p-2.5

                  ${
                    darkMode
                      ? `
                        border-slate-700
                        bg-slate-900
                      `
                      : `
                        border-slate-200
                        bg-white
                      `
                  }
                `}
              >
                <p className="text-[8px] font-bold uppercase text-slate-400">
                  Date
                </p>

                <p
                  className={`
                    mt-1
                    truncate
                    text-[10px]
                    font-bold

                    ${
                      darkMode
                        ? "text-white"
                        : "text-slate-800"
                    }
                  `}
                >
                  {appointment?.appointmentDate ||
                    "—"}
                </p>
              </div>

              <div
                className={`
                  rounded-xl
                  border
                  p-2.5

                  ${
                    darkMode
                      ? `
                        border-slate-700
                        bg-slate-900
                      `
                      : `
                        border-slate-200
                        bg-white
                      `
                  }
                `}
              >
                <p className="text-[8px] font-bold uppercase text-slate-400">
                  Time
                </p>

                <p
                  className={`
                    mt-1
                    truncate
                    text-[10px]
                    font-bold

                    ${
                      darkMode
                        ? "text-white"
                        : "text-slate-800"
                    }
                  `}
                >
                  {appointment?.appointmentTime ||
                    "—"}
                </p>
              </div>
            </div>
          </div>

          <div className="mt-5 grid grid-cols-2 gap-2.5">

            <button
              type="button"
              onClick={onCancel}
              disabled={deleting}
              className={`
                h-11
                rounded-xl
                border
                text-xs
                font-black
                transition
                active:scale-[0.98]
                disabled:opacity-50

                ${
                  darkMode
                    ? `
                      border-slate-700
                      bg-slate-800
                      text-slate-200
                      hover:bg-slate-700
                    `
                    : `
                      border-slate-200
                      bg-white
                      text-slate-700
                      hover:bg-slate-50
                    `
                }
              `}
            >
              Cancel
            </button>

            <button
              type="button"
              onClick={onConfirm}
              disabled={deleting}
              className="
                flex
                h-11
                items-center
                justify-center
                gap-2
                rounded-xl
                bg-red-600
                text-xs
                font-black
                text-white
                shadow-lg
                shadow-red-500/20
                transition
                hover:bg-red-700
                active:scale-[0.98]
                disabled:cursor-not-allowed
                disabled:opacity-60
              "
            >
              {deleting ? (
                <>
                  <Loader2
                    size={15}
                    className="animate-spin"
                  />
                  Deleting...
                </>
              ) : (
                <>
                  <Trash2 size={15} />
                  Delete
                </>
              )}
            </button>
          </div>
        </div>
      </div>

      <style>
        {`
          @keyframes modalIn {
            from {
              opacity: 0;
              transform: translateY(14px) scale(0.96);
            }

            to {
              opacity: 1;
              transform: translateY(0) scale(1);
            }
          }
        `}
      </style>
    </div>
  );
}

/* =========================================================
   SUCCESS POPUP
========================================================= */

function SuccessPopup({
  title,
  message,
  darkMode,
  onClose,
}) {
  return (
    <div
      className="
        fixed
        inset-x-0
        top-0
        z-[100000]
        flex
        justify-center
        pointer-events-none
        px-4
        pt-5
        sm:pt-7
      "
    >
      <div
        className={`
          pointer-events-auto
          relative
          w-full
          max-w-[430px]
          overflow-hidden
          rounded-2xl
          border
          shadow-2xl
          animate-[toastIn_0.3s_ease-out]

          ${
            darkMode
              ? `
                border-emerald-400/20
                bg-slate-900
                shadow-black/50
              `
              : `
                border-emerald-200
                bg-white
                shadow-emerald-900/10
              `
          }
        `}
      >
        <div
          className="
            absolute
            bottom-0
            left-0
            h-1
            w-full
            origin-left
            bg-emerald-500
            animate-[toastProgress_2.6s_linear_forwards]
          "
        />

        <div className="flex items-start gap-3 p-4">

          <div
            className={`
              flex
              h-10
              w-10
              shrink-0
              items-center
              justify-center
              rounded-xl

              ${
                darkMode
                  ? `
                    bg-emerald-500/10
                    text-emerald-300
                  `
                  : `
                    bg-emerald-50
                    text-emerald-600
                  `
              }
            `}
          >
            <CheckCircle2 size={21} />
          </div>

          <div className="min-w-0 flex-1">
            <p
              className={`
                text-sm
                font-black

                ${
                  darkMode
                    ? "text-white"
                    : "text-slate-900"
                }
              `}
            >
              {title}
            </p>

            <p
              className={`
                mt-0.5
                text-[11px]
                leading-relaxed

                ${
                  darkMode
                    ? "text-slate-400"
                    : "text-slate-500"
                }
              `}
            >
              {message}
            </p>
          </div>

          <button
            type="button"
            onClick={onClose}
            className={`
              shrink-0
              rounded-lg
              p-1

              ${
                darkMode
                  ? `
                    text-slate-500
                    hover:bg-slate-800
                    hover:text-white
                  `
                  : `
                    text-slate-400
                    hover:bg-slate-100
                    hover:text-slate-700
                  `
              }
            `}
          >
            <X size={15} />
          </button>
        </div>
      </div>

      <style>
        {`
          @keyframes toastIn {
            from {
              opacity: 0;
              transform: translateY(-18px) scale(0.96);
            }

            to {
              opacity: 1;
              transform: translateY(0) scale(1);
            }
          }

          @keyframes toastProgress {
            from {
              transform: scaleX(1);
            }

            to {
              transform: scaleX(0);
            }
          }
        `}
      </style>
    </div>
  );
}

/* =========================================================
   ERROR POPUP
========================================================= */

function ErrorPopup({
  title,
  message,
  darkMode,
  onClose,
}) {
  return (
    <div
      className="
        fixed
        inset-x-0
        top-0
        z-[100000]
        flex
        justify-center
        pointer-events-none
        px-4
        pt-5
      "
    >
      <div
        className={`
          pointer-events-auto
          w-full
          max-w-[430px]
          rounded-2xl
          border
          shadow-2xl

          ${
            darkMode
              ? `
                border-red-400/20
                bg-slate-900
              `
              : `
                border-red-200
                bg-white
              `
          }
        `}
      >
        <div className="flex items-start gap-3 p-4">

          <div
            className={`
              flex
              h-10
              w-10
              shrink-0
              items-center
              justify-center
              rounded-xl

              ${
                darkMode
                  ? `
                    bg-red-500/10
                    text-red-300
                  `
                  : `
                    bg-red-50
                    text-red-600
                  `
              }
            `}
          >
            <AlertTriangle size={20} />
          </div>

          <div className="min-w-0 flex-1">
            <p
              className={`
                text-sm
                font-black

                ${
                  darkMode
                    ? "text-white"
                    : "text-slate-900"
                }
              `}
            >
              {title}
            </p>

            <p
              className={`
                mt-0.5
                text-[11px]
                leading-relaxed

                ${
                  darkMode
                    ? "text-slate-400"
                    : "text-slate-500"
                }
              `}
            >
              {message}
            </p>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="rounded-lg p-1 text-slate-400 hover:bg-slate-100"
          >
            <X size={15} />
          </button>
        </div>
      </div>
    </div>
  );
}

/* =========================================================
   MOBILE APPOINTMENT CARD
========================================================= */

function AppointmentCard({
  appointment: r,
  onStatus,
  onDelete,
  updatingId,
  deletingId,
  darkMode,
}) {
  return (
    <div
      className={`
        w-full
        min-w-0
        max-w-full
        overflow-hidden
        rounded-2xl
        border
        shadow-sm

        ${
          darkMode
            ? `
              border-slate-700/80
              bg-slate-900
              shadow-black/20
            `
            : `
              border-slate-200
              bg-white
            `
        }
      `}
    >
      {/* HEADER */}

      <div
        className={`
          flex
          min-w-0
          items-center
          justify-between
          gap-2
          border-b
          p-3

          ${
            darkMode
              ? "border-slate-700"
              : "border-slate-100"
          }
        `}
      >
        <div className="flex min-w-0 flex-1 items-center gap-2.5">

          <div
            className={`
              flex
              h-9
              w-9
              shrink-0
              items-center
              justify-center
              rounded-xl
              border

              ${
                darkMode
                  ? `
                    border-cyan-400/30
                    bg-cyan-500/10
                    text-cyan-300
                  `
                  : `
                    border-cyan-100
                    bg-cyan-50
                    text-cyan-600
                  `
              }
            `}
          >
            <UserRound size={17} />
          </div>

          <div className="min-w-0 flex-1">
            <h3
              className={`
                truncate
                text-sm
                font-black

                ${
                  darkMode
                    ? "text-white"
                    : "text-slate-900"
                }
              `}
            >
              {r.patientName ||
                "Unknown Patient"}
            </h3>

            <p
              className={`
                mt-0.5
                truncate
                text-[8px]

                ${
                  darkMode
                    ? "text-slate-400"
                    : "text-slate-400"
                }
              `}
            >
              Appointment #
              {r.appointmentId}
            </p>
          </div>
        </div>

        <StatusBadge
          status={r.status}
        />
      </div>

      {/* DETAILS */}

      <div
        className="
          grid
          grid-cols-2
          gap-2
          p-3
        "
      >
        <InfoItem
          icon={Stethoscope}
          label="Doctor"
          value={
            r.doctorName || "—"
          }
          darkMode={darkMode}
        />

        <InfoItem
          icon={Layers}
          label="Service"
          value={
            r.serviceName || "—"
          }
          darkMode={darkMode}
        />

        <InfoItem
          icon={CalendarDays}
          label="Date"
          value={
            r.appointmentDate ||
            "—"
          }
          darkMode={darkMode}
        />

        <InfoItem
          icon={Clock3}
          label="Time"
          value={
            r.appointmentTime ||
            "—"
          }
          darkMode={darkMode}
        />

        <InfoItem
          icon={Phone}
          label="Phone"
          value={r.phone || "—"}
          darkMode={darkMode}
        />

        <InfoItem
          icon={Mail}
          label="Email"
          value={r.email || "—"}
          darkMode={darkMode}
        />
      </div>

      {/* MESSAGE */}

      {r.message && (
        <div
          className={`
            mx-3
            mb-3
            rounded-xl
            border
            p-2.5

            ${
              darkMode
                ? `
                  border-slate-700
                  bg-slate-950
                `
                : `
                  border-slate-200
                  bg-slate-50
                `
            }
          `}
        >
          <div
            className={`
              mb-1
              flex
              items-center
              gap-1
              text-[8px]
              font-bold
              uppercase
              tracking-wide

              ${
                darkMode
                  ? "text-slate-300"
                  : "text-slate-500"
              }
            `}
          >
            <MessageSquareText
              size={11}
            />

            Message
          </div>

          <p
            className={`
              line-clamp-2
              break-words
              text-[10px]
              leading-relaxed

              ${
                darkMode
                  ? "text-white"
                  : "text-slate-700"
              }
            `}
          >
            {r.message}
          </p>
        </div>
      )}

      {/* ACTION */}

      <div
        className={`
          flex
          items-center
          gap-2
          border-t
          p-3

          ${
            darkMode
              ? "border-slate-700"
              : "border-slate-100"
          }
        `}
      >
        <select
          value={
            r.status || "PENDING"
          }
          disabled={
            updatingId ===
            r.appointmentId
          }
          onChange={(e) =>
            onStatus(
              r,
              e.target.value
            )
          }
          className={`
            h-10
            min-w-0
            flex-1
            rounded-xl
            border
            px-2
            text-[9px]
            font-bold
            outline-none
            disabled:opacity-50

            ${
              darkMode
                ? `
                  border-slate-600
                  bg-slate-800
                  text-white
                  focus:border-cyan-400
                `
                : `
                  border-slate-200
                  bg-white
                  text-slate-900
                  focus:border-cyan-400
                `
            }
          `}
        >
          <option value="PENDING">
            PENDING
          </option>

          <option value="APPROVED">
            APPROVED
          </option>

          <option value="REJECTED">
            REJECTED
          </option>

        </select>

        <button
          type="button"
          onClick={() => onDelete(r)}
          disabled={
            deletingId ===
            r.appointmentId
          }
          className={`
            flex
            h-10
            w-10
            shrink-0
            items-center
            justify-center
            rounded-xl
            border
            transition
            active:scale-95
            disabled:opacity-50

            ${
              darkMode
                ? `
                  border-red-400/30
                  bg-red-500/10
                  text-red-300
                  hover:bg-red-500/20
                `
                : `
                  border-red-100
                  bg-red-50
                  text-red-600
                  hover:bg-red-100
                `
            }
          `}
        >
          <Trash2 size={16} />
        </button>
      </div>
    </div>
  );
}

/* =========================================================
   INFO ITEM
========================================================= */

function InfoItem({
  icon: Icon,
  label,
  value,
  darkMode,
}) {
  return (
    <div
      className={`
        min-w-0
        overflow-hidden
        rounded-xl
        border
        p-2.5

        ${
          darkMode
            ? `
              border-slate-700
              bg-slate-950
            `
            : `
              border-slate-200
              bg-slate-50
            `
        }
      `}
    >
      <div
        className={`
          mb-1
          flex
          items-center
          gap-1
          text-[7px]
          font-bold
          uppercase
          tracking-wide

          ${
            darkMode
              ? "text-slate-300"
              : "text-slate-500"
          }
        `}
      >
        <Icon
          size={10}
          className={
            darkMode
              ? "text-cyan-300"
              : "text-cyan-600"
          }
        />

        {label}
      </div>

      <p
        className={`
          truncate
          text-[10px]
          font-bold

          ${
            darkMode
              ? "text-white"
              : "text-slate-800"
          }
        `}
      >
        {value}
      </p>
    </div>
  );
}

/* =========================================================
   STATUS BADGE
========================================================= */

function StatusBadge({
  status,
}) {
  const value =
    status || "PENDING";

  let style = `
    border-amber-200
    bg-amber-50
    text-amber-700
    dark:border-amber-400/30
    dark:bg-amber-500/15
    dark:text-amber-300
  `;

  if (
    value === "APPROVED" ||
    value === "CONFIRMED"
  ) {
    style = `
      border-blue-200
      bg-blue-50
      text-blue-700
      dark:border-blue-400/30
      dark:bg-blue-500/15
      dark:text-blue-300
    `;
  }

  if (value === "COMPLETED") {
    style = `
      border-emerald-200
      bg-emerald-50
      text-emerald-700
      dark:border-emerald-400/30
      dark:bg-emerald-500/15
      dark:text-emerald-300
    `;
  }

  if (
    value === "REJECTED" ||
    value === "CANCELLED"
  ) {
    style = `
      border-red-200
      bg-red-50
      text-red-700
      dark:border-red-400/30
      dark:bg-red-500/15
      dark:text-red-300
    `;
  }

  return (
    <span
      className={`
        flex
        max-w-[100px]
        shrink-0
        items-center
        gap-1
        rounded-lg
        border
        px-2
        py-1
        text-[7px]
        font-black
        uppercase

        ${style}
      `}
    >
      <span
        className="
          h-1.5
          w-1.5
          shrink-0
          rounded-full
          bg-current
        "
      />

      <span className="truncate">
        {value}
      </span>
    </span>
  );
}

/* =========================================================
   DESKTOP ROW
========================================================= */

function DesktopRow({
  appointment: r,
  onStatus,
  onDelete,
  updatingId,
  deletingId,
  darkMode,
}) {
  return (
    <tr
      className={`
        border-b
        transition

        ${
          darkMode
            ? `
              border-slate-800
              hover:bg-slate-800/60
            `
            : `
              border-slate-100
              hover:bg-slate-50
            `
        }
      `}
    >
      {/* PATIENT */}

      <td className="px-5 py-4">
        <div className="flex items-center gap-3">

          <div
            className={`
              flex
              h-9
              w-9
              shrink-0
              items-center
              justify-center
              rounded-lg
              border

              ${
                darkMode
                  ? `
                    border-cyan-400/30
                    bg-cyan-500/10
                    text-cyan-300
                  `
                  : `
                    border-cyan-100
                    bg-cyan-50
                    text-cyan-600
                  `
              }
            `}
          >
            <UserRound size={16} />
          </div>

          <div className="min-w-0">
            <p
              className={`
                max-w-[180px]
                truncate
                font-bold

                ${
                  darkMode
                    ? "text-white"
                    : "text-slate-900"
                }
              `}
            >
              {r.patientName || "—"}
            </p>

            <p
              className={`
                max-w-[180px]
                truncate
                text-[10px]

                ${
                  darkMode
                    ? "text-slate-300"
                    : "text-slate-500"
                }
              `}
            >
              {r.phone || "No phone"}
            </p>
          </div>
        </div>
      </td>

      {/* DOCTOR */}

      <td
        className={`
          max-w-[160px]
          truncate
          px-4
          py-4
          text-xs
          font-semibold

          ${
            darkMode
              ? "text-white"
              : "text-slate-700"
          }
        `}
      >
        {r.doctorName || "—"}
      </td>

      {/* SERVICE */}

      <td
        className={`
          max-w-[160px]
          truncate
          px-4
          py-4
          text-xs
          font-semibold

          ${
            darkMode
              ? "text-white"
              : "text-slate-700"
          }
        `}
      >
        {r.serviceName || "—"}
      </td>

      {/* DATE */}

      <td
        className={`
          px-4
          py-4
          text-xs
          font-semibold

          ${
            darkMode
              ? "text-white"
              : "text-slate-700"
          }
        `}
      >
        {r.appointmentDate || "—"}
      </td>

      {/* TIME */}

      <td
        className={`
          px-4
          py-4
          text-xs
          font-semibold

          ${
            darkMode
              ? "text-white"
              : "text-slate-700"
          }
        `}
      >
        {r.appointmentTime || "—"}
      </td>

      {/* STATUS */}

      <td className="px-4 py-4">
        <select
          value={
            r.status || "PENDING"
          }
          disabled={
            updatingId ===
            r.appointmentId
          }
          onChange={(e) =>
            onStatus(
              r,
              e.target.value
            )
          }
          className={`
            rounded-lg
            border
            px-2.5
            py-2
            text-xs
            font-bold
            outline-none
            disabled:opacity-50

            ${
              darkMode
                ? `
                  border-slate-600
                  bg-slate-800
                  text-white
                  focus:border-cyan-400
                `
                : `
                  border-slate-200
                  bg-white
                  text-slate-900
                  focus:border-cyan-400
                `
            }
          `}
        >
          <option value="PENDING">
            PENDING
          </option>

          <option value="APPROVED">
            APPROVED
          </option>

          <option value="REJECTED">
            REJECTED
          </option>

          <option value="CONFIRMED">
            CONFIRMED
          </option>

          <option value="COMPLETED">
            COMPLETED
          </option>

          <option value="CANCELLED">
            CANCELLED
          </option>
        </select>
      </td>

      {/* DELETE */}

      <td className="px-4 py-4 text-center">
        <button
          type="button"
          onClick={() => onDelete(r)}
          disabled={
            deletingId ===
            r.appointmentId
          }
          className={`
            inline-flex
            h-9
            w-9
            items-center
            justify-center
            rounded-lg
            transition
            active:scale-95
            disabled:opacity-50

            ${
              darkMode
                ? `
                  text-red-300
                  hover:bg-red-500/15
                `
                : `
                  text-red-600
                  hover:bg-red-50
                `
            }
          `}
        >
          <Trash2 size={16} />
        </button>
      </td>
    </tr>
  );
}

/* =========================================================
   EMPTY STATE
========================================================= */

function EmptyState({
  darkMode,
}) {
  return (
    <div
      className={`
        flex
        min-h-[220px]
        w-full
        flex-col
        items-center
        justify-center
        rounded-2xl
        border
        border-dashed
        px-5
        text-center

        ${
          darkMode
            ? `
              border-slate-700
              bg-slate-900
            `
            : `
              border-slate-200
              bg-white
            `
        }
      `}
    >
      <div
        className={`
          mb-3
          flex
          h-12
          w-12
          items-center
          justify-center
          rounded-xl

          ${
            darkMode
              ? `
                bg-slate-800
                text-slate-300
              `
              : `
                bg-slate-100
                text-slate-400
              `
          }
        `}
      >
        <CalendarDays size={21} />
      </div>

      <h3
        className={`
          text-sm
          font-black

          ${
            darkMode
              ? "text-white"
              : "text-slate-900"
          }
        `}
      >
        No appointments found
      </h3>

      <p
        className={`
          mt-1
          max-w-xs
          text-[10px]
          leading-relaxed

          ${
            darkMode
              ? "text-slate-300"
              : "text-slate-500"
          }
        `}
      >
        There are no appointments
        matching your search.
      </p>
    </div>
  );
}

/* =========================================================
   MOBILE LOADING
========================================================= */

function LoadingCards({
  darkMode,
}) {
  return (
    <>
      {[1, 2, 3].map((item) => (
        <div
          key={item}
          className={`
            h-[230px]
            w-full
            animate-pulse
            rounded-2xl
            border

            ${
              darkMode
                ? `
                  border-slate-700
                  bg-slate-900
                `
                : `
                  border-slate-200
                  bg-white
                `
            }
          `}
        />
      ))}
    </>
  );
}

/* =========================================================
   DESKTOP LOADING
========================================================= */

function DesktopLoading({
  darkMode,
}) {
  return (
    <>
      {[1, 2, 3, 4, 5].map(
        (item) => (
          <tr key={item}>
            <td colSpan="7">
              <div
                className={`
                  m-2
                  h-12
                  animate-pulse
                  rounded-lg

                  ${
                    darkMode
                      ? "bg-slate-800"
                      : "bg-slate-100"
                  }
                `}
              />
            </td>
          </tr>
        )
      )}
    </>
  );
}