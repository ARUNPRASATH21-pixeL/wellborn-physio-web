import React, { useEffect, useState } from "react";
import { Link, Outlet, useLocation } from "react-router-dom";
import { API, postData } from "../services/api";

export default function UserShell() {
  const location = useLocation();

  const [darkMode, setDarkMode] = useState(() => {
    try {
      const saved = localStorage.getItem("wellborn-theme");
      if (saved === "dark") return true;
      if (saved === "light") return false;
      return window.matchMedia?.("(prefers-color-scheme: dark)").matches || false;
    } catch {
      return false;
    }
  });

  const [menuOpen, setMenuOpen] = useState(false);
  const [appointmentOpen, setAppointmentOpen] = useState(false);
  const [introVisible, setIntroVisible] = useState(false);

  // Success Alert State
  const [successAlert, setSuccessAlert] = useState({
    visible: false,
    title: "",
    message: "",
  });

  // Unique Premium Success Modal State for Appointment
  const [appointmentSuccessModal, setAppointmentSuccessModal] = useState({
    visible: false,
    patientName: "",
    department: "",
    date: "",
  });

  const [appointmentData, setAppointmentData] = useState({
    name: "",
    phone: "",
    email: "",
    date: "",
    department: "",
    problem: "",
  });

  const [appointmentLoading, setAppointmentLoading] = useState(false);
  const [appointmentError, setAppointmentError] = useState("");

  const links = [
    { name: "Home", path: "/user/home", icon: "fa-house" },
    { name: "About", path: "/user/about", icon: "fa-circle-info" },
    { name: "Services", path: "/user/services", icon: "fa-hand-holding-medical" },
    { name: "Doctors", path: "/user/doctors", icon: "fa-user-doctor" },
    { name: "Contact", path: "/user/contact", icon: "fa-phone" },
  ];

  /* =====================================================
     INTRO
  ===================================================== */

  useEffect(() => {
    let timer;

    try {
      const shown = sessionStorage.getItem("wellborn-intro-shown");

      if (!shown) {
        setIntroVisible(true);

        timer = window.setTimeout(() => {
          setIntroVisible(false);
          sessionStorage.setItem("wellborn-intro-shown", "true");
        }, 3400);
      }
    } catch {
      setIntroVisible(true);

      timer = window.setTimeout(() => {
        setIntroVisible(false);
      }, 3400);
    }

    return () => window.clearTimeout(timer);
  }, []);

  /* =====================================================
     THEME
  ===================================================== */

  useEffect(() => {
    const root = document.documentElement;

    if (darkMode) {
      root.classList.add("dark");
      localStorage.setItem("wellborn-theme", "dark");
    } else {
      root.classList.remove("dark");
      localStorage.setItem("wellborn-theme", "light");
    }
  }, [darkMode]);

  /* =====================================================
     ROUTE CHANGE
  ===================================================== */

  useEffect(() => {
    setMenuOpen(false);
    setAppointmentOpen(false);

    const html = document.documentElement;
    const body = document.body;

    html.classList.remove("wellborn-lock");
    body.classList.remove("wellborn-lock");

    html.style.removeProperty("overflow");
    body.style.removeProperty("overflow");
    body.style.removeProperty("touch-action");

    window.scrollTo({ top: 0, left: 0, behavior: "instant" });
  }, [location.pathname]);

  /* =====================================================
     SCROLL LOCK
  ===================================================== */

  useEffect(() => {
    const html = document.documentElement;
    const body = document.body;
    const locked = menuOpen || appointmentOpen || introVisible || appointmentSuccessModal.visible;

    if (locked) {
      html.classList.add("wellborn-lock");
      body.classList.add("wellborn-lock");
      html.style.overflow = "hidden";
      body.style.overflow = "hidden";
      body.style.touchAction = "none";
    } else {
      html.classList.remove("wellborn-lock");
      body.classList.remove("wellborn-lock");
      html.style.removeProperty("overflow");
      body.style.removeProperty("overflow");
      body.style.removeProperty("touch-action");
    }

    return () => {
      html.classList.remove("wellborn-lock");
      body.classList.remove("wellborn-lock");
      html.style.removeProperty("overflow");
      body.style.removeProperty("overflow");
      body.style.removeProperty("touch-action");
    };
  }, [menuOpen, appointmentOpen, introVisible, appointmentSuccessModal.visible]);

  /* =====================================================
     ESCAPE
  ===================================================== */

  useEffect(() => {
    const handleEscape = (event) => {
      if (event.key === "Escape") {
        setMenuOpen(false);
        setAppointmentOpen(false);
        setAppointmentSuccessModal((prev) => ({ ...prev, visible: false }));
      }
    };

    document.addEventListener("keydown", handleEscape);
    return () => document.removeEventListener("keydown", handleEscape);
  }, []);

  /* =====================================================
     HELPERS
  ===================================================== */

  const isActive = (path) => location.pathname === path;

  const toggleTheme = (event) => {
    const button = event.currentTarget;
    const rect = button.getBoundingClientRect();

    const x = ((rect.left + rect.width / 2) / window.innerWidth) * 100;
    const y = ((rect.top + rect.height / 2) / window.innerHeight) * 100;

    document.documentElement.style.setProperty("--theme-x", `${x}%`);
    document.documentElement.style.setProperty("--theme-y", `${y}%`);

    document.documentElement.classList.remove("theme-changing");
    void document.documentElement.offsetWidth;
    document.documentElement.classList.add("theme-changing");

    setDarkMode((previous) => !previous);

    window.setTimeout(() => {
      document.documentElement.classList.remove("theme-changing");
    }, 800);
  };

  const toggleMenu = () => setMenuOpen((previous) => !previous);
  const closeMenu = () => setMenuOpen(false);

  const openAppointment = () => {
    setMenuOpen(false);
    setAppointmentError("");
    window.setTimeout(() => setAppointmentOpen(true), 180);
  };

  const closeAppointment = () => setAppointmentOpen(false);

  const handleFormChange = (event) => {
    const { name, value } = event.target;

    setAppointmentData((previous) => ({
      ...previous,
      [name]: value,
    }));
  };

  const handleAppointmentSubmit = async (event) => {
    event.preventDefault();

    setAppointmentError("");
    setAppointmentLoading(true);

    try {
      await postData(API.APPOINTMENT_BOOK, {
        patientName: appointmentData.name,
        phone: appointmentData.phone,
        email: appointmentData.email,
        appointmentDate: appointmentData.date,
        serviceName: appointmentData.department,
        message: appointmentData.problem,
      });

      setAppointmentOpen(false);

      const submittedName = appointmentData.name;
      const submittedDept = appointmentData.department || "Physiotherapy Care";
      const submittedDate = appointmentData.date;

      setAppointmentData({
        name: "",
        phone: "",
        email: "",
        date: "",
        department: "",
        problem: "",
      });

      setAppointmentSuccessModal({
        visible: true,
        patientName: submittedName,
        department: submittedDept,
        date: submittedDate,
      });

    } catch (err) {
      console.error(err);
      setAppointmentError("Unable to connect to server. Please try again.");
    } finally {
      setAppointmentLoading(false);
    }
  };

  const today = new Date().toISOString().split("T")[0];

  /* =====================================================
     THEME SWITCH
  ===================================================== */

  const ThemeSwitch = ({ mobile = false }) => (
    <button
      type="button"
      onClick={toggleTheme}
      aria-label={darkMode ? "Switch to light mode" : "Switch to dark mode"}
      aria-pressed={darkMode}
      className={`theme-switch ${
        mobile ? "theme-switch-mobile" : "theme-switch-desktop"
      } ${darkMode ? "theme-switch-dark" : "theme-switch-light"}`}
    >
      <span className="theme-side-icon theme-sun">
        <i className="fa-solid fa-sun" />
      </span>

      <span className="theme-side-icon theme-moon">
        <i className="fa-solid fa-moon" />
      </span>

      <span className="theme-knob">
        <i
          className={`fa-solid ${
            darkMode ? "fa-moon theme-knob-moon" : "fa-sun theme-knob-sun"
          }`}
        />
      </span>
    </button>
  );

  return (
    <div className="user-shell">

      {/* =================================================
          PREMIUM INTRO
      ================================================= */}

      {introVisible && (
        <div className="wellborn-intro">
          <div className="intro-background">
            <div className="intro-orb intro-orb-one" />
            <div className="intro-orb intro-orb-two" />
            <div className="intro-orb intro-orb-three" />
          </div>

          <div className="intro-grid" />

          <div className="intro-content">
            <div className="intro-logo-wrap">
              <div className="intro-logo-ring intro-ring-one" />
              <div className="intro-logo-ring intro-ring-two" />
              <div className="intro-logo-glow" />

              <div className="intro-logo">
                <img
                  src="/assets/wellborn physio.jpg"
                  alt="Wellborn Physio"
                />
              </div>
            </div>

            <div className="intro-brand">
              <h1>
                Wellborn<span> Physio</span>
              </h1>

              <div className="intro-line">
                <span />
                <p>REHAB CENTRE</p>
                <span />
              </div>
            </div>

            <p className="intro-tagline">
              Move Better. Live Better.
            </p>

            <div className="intro-loading">
              <div className="intro-loading-track">
                <span />
              </div>

              <p>Preparing your wellness experience</p>
            </div>
          </div>

          <div className="intro-corner intro-corner-tl" />
          <div className="intro-corner intro-corner-tr" />
          <div className="intro-corner intro-corner-bl" />
          <div className="intro-corner intro-corner-br" />
        </div>
      )}

      {/* =================================================
          THEME GLOW
      ================================================= */}

      <div className="theme-change-glow" />

      {/* =================================================
          UNIQUE PREMIUM SUCCESS MODAL FOR APPOINTMENT
      ================================================= */}

      {appointmentSuccessModal.visible && (
        <div className="appointment-modal-overlay">
          <div
            className="appointment-modal-backdrop"
            onClick={() => setAppointmentSuccessModal((prev) => ({ ...prev, visible: false }))}
          />
          <div className="appointment-success-modal-card">
            <div className="modal-glow-effect" />
            
            <button
              type="button"
              className="modal-close-btn"
              onClick={() => setAppointmentSuccessModal((prev) => ({ ...prev, visible: false }))}
            >
              <i className="fa-solid fa-xmark" />
            </button>

            <div className="success-icon-wrapper">
              <div className="success-badge-icon">
                <i className="fa-solid fa-circle-check" />
              </div>
              <div className="sparkle-float-1"><i className="fa-solid fa-wand-magic-sparkles" /></div>
            </div>

            <div className="modal-content-text">
              <div className="modal-pill-tag">
                <i className="fa-solid fa-sparkles" /> Appointment Confirmed
              </div>
              <h3>Thank You, {appointmentSuccessModal.patientName}!</h3>
              <p>
                Your appointment for <strong>{appointmentSuccessModal.department}</strong> on <strong>{appointmentSuccessModal.date || "Scheduled Date"}</strong> has been successfully booked. Our team will contact you shortly.
              </p>
            </div>

            <button
              type="button"
              onClick={() => setAppointmentSuccessModal((prev) => ({ ...prev, visible: false }))}
              className="modal-action-btn"
            >
              <span>Back to Wellness</span>
              <i className="fa-solid fa-arrow-right" />
            </button>
          </div>
        </div>
      )}

      {/* =================================================
          DESKTOP NAVBAR
      ================================================= */}

      <header className="desktop-navbar">
        <div className="desktop-navbar-inner">

          <Link to="/user/home" className="desktop-brand">
            <div className="brand-logo desktop-brand-logo">
              <span className="brand-logo-glow" />
              <span className="brand-logo-border" />

              <img
                src="/assets/wellborn physio.jpg"
                alt="Wellborn Physio"
              />
            </div>

            <div className="brand-text">
              <h1>
                Wellborn<span> Physio</span>
              </h1>

              <div className="brand-sub">
                <span />
                <p>Rehab Centre</p>
              </div>
            </div>
          </Link>

          <nav className="desktop-navigation">
            <div className="desktop-navigation-pill">
              {links.map((item) => {
                const active = isActive(item.path);

                return (
                  <Link
                    key={item.path}
                    to={item.path}
                    className={`desktop-nav-link ${active ? "active" : ""}`}
                  >
                    <i className={`fa-solid ${item.icon}`} />
                    <span>{item.name}</span>
                  </Link>
                );
              })}
            </div>
          </nav>

          <div className="desktop-actions">
            <button
              type="button"
              onClick={openAppointment}
              className="desktop-appointment"
            >
              <i className="fa-solid fa-calendar-check" />
              <span>Appointment</span>
            </button>

            <ThemeSwitch />
          </div>
        </div>
      </header>

      {/* =================================================
          MOBILE NAVBAR
      ================================================= */}

      <header className="mobile-navbar">
        <Link to="/user/home" className="mobile-brand">
          <div className="brand-logo mobile-brand-logo">
            <span className="brand-logo-glow" />
            <span className="brand-logo-border" />

            <img
              src="/assets/wellborn physio.jpg"
              alt="Wellborn Physio"
            />
          </div>

          <div className="mobile-brand-text">
            <h1>
              Wellborn<span> Physio</span>
            </h1>

            <div className="brand-sub">
              <span />
              <p>Rehab Centre</p>
            </div>
          </div>
        </Link>

        <div className="mobile-actions">
          <ThemeSwitch mobile />

          <button
            type="button"
            onClick={toggleMenu}
            aria-label={menuOpen ? "Close navigation menu" : "Open navigation menu"}
            aria-expanded={menuOpen}
            className={`mobile-menu-button ${
              menuOpen ? "menu-button-open" : ""
            }`}
          >
            <i className={`fa-solid ${menuOpen ? "fa-xmark" : "fa-bars"}`} />
          </button>
        </div>
      </header>

      {/* =================================================
          MAIN
      ================================================= */}

      <main className="user-main">
        <Outlet
          context={{
            isHomePage: location.pathname === "/user/home",
          }}
        />
      </main>

      {/* =================================================
          MOBILE BACKDROP
      ================================================= */}

      <div
        className={`mobile-backdrop ${menuOpen ? "show" : ""}`}
        onClick={closeMenu}
      />

      {/* =================================================
          MOBILE MENU
      ================================================= */}

      <aside className={`mobile-menu-panel ${menuOpen ? "show" : ""}`}>
        <div className="mobile-menu-handle">
          <span />
        </div>

        <div className="mobile-menu-options">
          {links.map((item, index) => {
            const active = isActive(item.path);

            return (
              <Link
                key={item.path}
                to={item.path}
                onClick={closeMenu}
                style={{
                  "--menu-delay": `${0.05 + index * 0.05}s`,
                }}
                className={`mobile-menu-option ${active ? "active" : ""}`}
              >
                {active && <span className="active-line" />}

                <span className="mobile-option-icon">
                  <i className={`fa-solid ${item.icon}`} />
                </span>

                <span className="mobile-option-name">
                  {item.name}
                </span>

                <span className="mobile-option-arrow">
                  <i className="fa-solid fa-chevron-right" />
                </span>
              </Link>
            );
          })}

          <button
            type="button"
            onClick={openAppointment}
            className="mobile-appointment-button"
          >
            <span className="mobile-appointment-icon">
              <i className="fa-solid fa-calendar-check" />
            </span>

            <span>Book Appointment</span>

            <i className="fa-solid fa-arrow-right" />
          </button>
        </div>
      </aside>

      {/* =================================================
          APPOINTMENT POPUP
      ================================================= */}

      {appointmentOpen && (
        <div
          className="appointment-overlay"
          onClick={closeAppointment}
        >
          <div
            className="appointment-modal"
            onClick={(event) => event.stopPropagation()}
          >
            <div className="appointment-handle">
              <span />
            </div>

            <div className="appointment-header">
              <div className="appointment-header-glow glow-one" />
              <div className="appointment-header-glow glow-two" />

              <button
                type="button"
                onClick={closeAppointment}
                aria-label="Close appointment"
                className="appointment-close"
              >
                <i className="fa-solid fa-xmark" />
              </button>

              <div className="appointment-icon">
                <i className="fa-solid fa-calendar-days" />
              </div>

              <h2>Book Appointment</h2>
              <p>Schedule your physiotherapy consultation</p>
            </div>

            <form
              onSubmit={handleAppointmentSubmit}
              className="appointment-form"
            >
              {appointmentError && (
                <p
                  style={{
                    color: "#dc2626",
                    fontSize: 11,
                    fontWeight: 700,
                    marginBottom: 8,
                  }}
                >
                  {appointmentError}
                </p>
              )}

              <div className="appointment-field">
                <label htmlFor="popup-name">Full Name</label>
                <div className="appointment-input-wrap">
                  <span>
                    <i className="fa-solid fa-user" />
                  </span>
                  <input
                    id="popup-name"
                    type="text"
                    name="name"
                    value={appointmentData.name}
                    onChange={handleFormChange}
                    placeholder="Enter your name"
                    autoComplete="name"
                    required
                  />
                </div>
              </div>

              <div className="appointment-field">
                <label htmlFor="popup-phone">Phone Number</label>
                <div className="appointment-input-wrap">
                  <span>
                    <i className="fa-solid fa-phone" />
                  </span>
                  <input
                    id="popup-phone"
                    type="tel"
                    name="phone"
                    value={appointmentData.phone}
                    onChange={handleFormChange}
                    placeholder="Enter phone number"
                    inputMode="numeric"
                    autoComplete="tel"
                    required
                  />
                </div>
              </div>

              <div className="appointment-field">
                <label htmlFor="popup-email">Email Address</label>
                <div className="appointment-input-wrap">
                  <span>
                    <i className="fa-solid fa-envelope" />
                  </span>
                  <input
                    id="popup-email"
                    type="email"
                    name="email"
                    value={appointmentData.email}
                    onChange={handleFormChange}
                    placeholder="Enter your email address"
                    autoComplete="email"
                    required
                  />
                </div>
              </div>

              <div className="appointment-field">
                <label htmlFor="popup-date">Preferred Date</label>
                <div className="appointment-input-wrap">
                  <span>
                    <i className="fa-solid fa-calendar-days" />
                  </span>
                  <input
                    id="popup-date"
                    type="date"
                    name="date"
                    value={appointmentData.date}
                    onChange={handleFormChange}
                    min={today}
                    required
                  />
                </div>
              </div>

              <div className="appointment-field">
                <label>Treatment Type</label>
                <div className="stylish-treatments-grid">
                  {[
                    { label: "Pain Management", icon: "fa-hand-holding-medical" },
                    { label: "Orthopaedic", icon: "fa-bone" },
                    { label: "Sports Physio", icon: "fa-person-running" },
                    { label: "Neurological", icon: "fa-brain" },
                    { label: "Pediatric", icon: "fa-child" },
                    { label: "Rehabilitation", icon: "fa-rotate-right" },
                    { label: "Other", icon: "fa-stethoscope" },
                  ].map((item) => {
                    const isSelected = appointmentData.department === item.label;

                    return (
                      <button
                        key={item.label}
                        type="button"
                        className={`treatment-pill ${isSelected ? "selected" : ""}`}
                        onClick={() =>
                          setAppointmentData((prev) => ({
                            ...prev,
                            department: item.label,
                          }))
                        }
                      >
                        <i className={`fa-solid ${item.icon}`} />
                        <span>{item.label}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              <div className="appointment-field">
                <label htmlFor="popup-problem">Describe Your Problem</label>
                <div className="appointment-input-wrap appointment-textarea-wrap">
                  <span>
                    <i className="fa-solid fa-message" />
                  </span>
                  <textarea
                    id="popup-problem"
                    name="problem"
                    value={appointmentData.problem}
                    onChange={handleFormChange}
                    placeholder="Tell us about your problem..."
                    rows={3}
                    required
                  />
                </div>
              </div>

              <button
                type="submit"
                className="appointment-submit"
                disabled={appointmentLoading}
              >
                <span>
                  <i className="fa-solid fa-calendar-check" />
                  {appointmentLoading ? "Booking..." : "Book Appointment"}
                </span>
                <i className="fa-solid fa-arrow-right" />
              </button>

              <p className="appointment-note">
                Your appointment request will be securely submitted.
              </p>
            </form>
          </div>
        </div>
      )}

      {/* =================================================
          GLOBAL WHATSAPP
      ================================================= */}

      <a
        href="https://wa.me/919342752147?text=Hello%20Wellborn%20Physio%2C%20I%20would%20like%20to%20book%20an%20appointment"
        target="_blank"
        rel="noopener noreferrer"
        aria-label="Chat on WhatsApp"
        className="wellborn-global-whatsapp"
      >
        <span className="wellborn-whatsapp-pulse" />

        <span className="wellborn-whatsapp-button">
          <svg
            viewBox="0 0 24 24"
            xmlns="http://www.w3.org/2000/svg"
            aria-hidden="true"
          >
            <path d="M20.52 3.48A11.8 11.8 0 0 0 12.08 0C5.57 0 .27 5.3.27 11.81c0 2.08.54 4.11 1.57 5.9L.2 24l6.43-1.68a11.8 11.8 0 0 0 5.45 1.38h.01c6.51 0 11.81-5.3 11.81-11.81 0-3.15-1.23-6.11-3.38-8.41ZM12.09 21.7h-.01a9.84 9.84 0 0 1-5.02-1.37l-.36-.21-3.82 1 1.02-3.72-.23-.38a9.84 9.84 0 0 1-1.51-5.21C2.16 6.38 6.62 1.92 12.09 1.92c2.65 0 5.14 1.03 7.01 2.9a9.84 9.84 0 0 1 2.9 7c0 5.47-4.46 9.93-9.91 9.93Zm5.44-7.44c-.3-.15-1.76-.87-2.03-.97-.27-.1-.47-.15-.67.15-.2.3-.77.97-.95 1.17-.17.2-.35.22-.65.07-.3-.15-1.28-.47-2.43-1.5-.9-.8-1.5-1.78-1.68-2.08-.17-.3-.02-.46.13-.61.14-.14.3-.35.45-.52.15-.17.2-.3.3-.5.1-.2.05-.37-.02-.52-.07-.15-.67-1.62-.92-2.22-.24-.58-.49-.5-.67-.51h-.57c-.2 0-.52.07-.8.37-.27.3-1.05 1.03-1.05 2.5s1.07 2.9 1.22 3.1c.15.2 2.1 3.2 5.09 4.49.71.31 1.26.49 1.69.63.71.23 1.35.2 1.86.12.57-.08 1.76-.72 2.01-1.42.25-.7.25-1.3.17-1.42-.07-.12-.27-.2-.57-.35Z" />
          </svg>
        </span>
      </a>

      {/* =================================================
          CSS
      ================================================= */}

      <style>{`
        *,
        *::before,
        *::after {
          box-sizing: border-box;
          -webkit-tap-highlight-color: transparent;
        }

        html,
        body,
        #root {
          width: 100%;
          min-height: 100%;
          margin: 0;
          padding: 0;
        }

        html {
          overflow-x: hidden;
          background: #f6f9fd;
          scroll-behavior: smooth;
        }

        html.dark {
          background: #020617;
        }

        body {
          margin: 0;
          overflow-x: hidden;
          overflow-y: auto;
          font-family: "Poppins", system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
          background: #f6f9fd;
          color: #0f172a;
          -webkit-overflow-scrolling: touch;
          overscroll-behavior-x: none;
          transition: background-color .7s ease, color .7s ease;
        }

        .dark body {
          background: #020617;
          color: #f8fafc;
        }

        #root {
          min-height: 100dvh;
          overflow-x: hidden;
        }

        html.wellborn-lock,
        body.wellborn-lock {
          overflow: hidden !important;
        }

        body.wellborn-lock {
          touch-action: none;
        }

        .user-shell {
          position: relative;
          width: 100%;
          min-height: 100dvh;
          overflow-x: clip;
          background: #f6f9fd;
          color: #0f172a;
          transition: background-color .7s ease, color .7s ease;
        }

        .dark .user-shell {
          background: #020617;
          color: #f8fafc;
        }

        .user-main {
          width: 100%;
          min-height: 100dvh;
          overflow: visible;
          padding-top: 92px;
        }

        /* =================================================
            APPOINTMENT SUCCESS MODAL POPUP STYLES
        ================================================= */

        .appointment-modal-overlay {
          position: fixed;
          inset: 0;
          z-index: 99999;
          display: flex;
          align-items: center;
          justify-content: center;
          padding: 20px;
          animation: fadeInOverlay 0.3s ease;
        }

        @keyframes fadeInOverlay {
          from { opacity: 0; }
          to { opacity: 1; }
        }

        .appointment-modal-backdrop {
          position: absolute;
          inset: 0;
          background: rgba(5, 7, 13, 0.75);
          backdrop-filter: blur(12px);
          -webkit-backdrop-filter: blur(12px);
        }

        .appointment-success-modal-card {
          position: relative;
          z-index: 10;
          width: 100%;
          max-width: 420px;
          padding: 32px;
          border-radius: 28px;
          background: linear-gradient(145deg, #0f172a, #0b1120);
          border: 1px solid rgba(103, 232, 249, 0.25);
          box-shadow: 0 25px 60px rgba(0, 0, 0, 0.5), 0 0 40px rgba(37, 99, 235, 0.2);
          text-align: center;
          color: white;
          overflow: hidden;
          animation: modalScaleIn 0.35s cubic-bezier(0.22, 1, 0.36, 1);
        }

        @keyframes modalScaleIn {
          from { opacity: 0; transform: scale(0.85) translateY(20px); }
          to { opacity: 1; transform: scale(1) translateY(0); }
        }

        .modal-glow-effect {
          position: absolute;
          top: -60px;
          left: 50%;
          transform: translateX(-50%);
          width: 180px;
          height: 180px;
          border-radius: 50%;
          background: rgba(37, 99, 235, 0.35);
          filter: blur(40px);
          pointer-events: none;
        }

        .modal-close-btn {
          position: absolute;
          top: 18px;
          right: 18px;
          width: 32px;
          height: 32px;
          border-radius: 50%;
          background: rgba(255, 255, 255, 0.08);
          border: 1px solid rgba(255, 255, 255, 0.12);
          color: #94a3b8;
          display: flex;
          align-items: center;
          justify-content: center;
          cursor: pointer;
          transition: all 0.2s ease;
        }

        .modal-close-btn:hover {
          background: rgba(255, 255, 255, 0.15);
          color: white;
        }

        .success-icon-wrapper {
          position: relative;
          width: 76px;
          height: 76px;
          margin: 0 auto;
          display: flex;
          align-items: center;
          justify-content: center;
          border-radius: 24px;
          background: linear-gradient(135deg, rgba(37, 99, 235, 0.2), rgba(6, 182, 212, 0.2));
          border: 1px solid rgba(103, 232, 249, 0.3);
        }

        .success-badge-icon {
          color: #22d3ee;
          font-size: 32px;
        }

        .sparkle-float-1 {
          position: absolute;
          top: -6px;
          right: -6px;
          color: #38bdf8;
          animation: bounceSparkle 2s ease-in-out infinite;
        }

        @keyframes bounceSparkle {
          0%, 100% { transform: translateY(0) scale(1); }
          50% { transform: translateY(-4px) scale(1.15); }
        }

        .modal-content-text {
          margin-top: 20px;
        }

        .modal-pill-tag {
          display: inline-flex;
          align-items: center;
          gap: 6px;
          padding: 5px 12px;
          border-radius: 999px;
          background: rgba(34, 211, 238, 0.1);
          border: 1px solid rgba(34, 211, 238, 0.25);
          color: #22d3ee;
          font-size: 10px;
          font-weight: 800;
          letter-spacing: 0.05em;
          text-transform: uppercase;
        }

        .modal-content-text h3 {
          margin-top: 14px;
          font-size: 22px;
          font-weight: 900;
          color: white;
        }

        .modal-content-text p {
          margin-top: 8px;
          color: #94a3b8;
          font-size: 12px;
          line-height: 1.7;
        }

        .modal-action-btn {
          width: 100%;
          min-height: 48px;
          margin-top: 24px;
          border: none;
          border-radius: 14px;
          background: linear-gradient(135deg, #2563eb, #0891b2);
          color: white;
          font-size: 12px;
          font-weight: 850;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 8px;
          cursor: pointer;
          box-shadow: 0 10px 25px rgba(37, 99, 235, 0.3);
          transition: transform 0.2s ease;
        }

        .modal-action-btn:hover {
          transform: translateY(-2px);
        }

        /* =================================================
            PREMIUM INTRO
        ================================================= */

        .wellborn-intro {
          position: fixed;
          inset: 0;
          z-index: 9999999;
          width: 100vw;
          height: 100dvh;
          display: flex;
          align-items: center;
          justify-content: center;
          overflow: hidden;
          background: radial-gradient(circle at 50% 45%, #102a56 0%, #07152d 34%, #020817 70%, #01040b 100%);
          color: white;
          animation: introAppear .8s cubic-bezier(.22,1,.36,1) both;
        }

        .intro-background {
          position: absolute;
          inset: 0;
          overflow: hidden;
          pointer-events: none;
        }

        .intro-grid {
          position: absolute;
          inset: 0;
          opacity: .13;
          pointer-events: none;
          background-image: linear-gradient(rgba(96,165,250,.12) 1px, transparent 1px), linear-gradient(90deg, rgba(96,165,250,.12) 1px, transparent 1px);
          background-size: 45px 45px;
          mask-image: radial-gradient(ellipse at center, black 0%, transparent 72%);
          animation: introGridMove 8s linear infinite;
        }

        .intro-orb {
          position: absolute;
          border-radius: 50%;
          filter: blur(70px);
          opacity: .35;
          pointer-events: none;
        }

        .intro-orb-one {
          width: 360px;
          height: 360px;
          top: -130px;
          left: -100px;
          background: rgba(37,99,235,.45);
          animation: introOrbOne 6s ease-in-out infinite;
        }

        .intro-orb-two {
          width: 420px;
          height: 420px;
          right: -160px;
          bottom: -150px;
          background: rgba(6,182,212,.32);
          animation: introOrbTwo 7s ease-in-out infinite;
        }

        .intro-orb-three {
          width: 250px;
          height: 250px;
          left: 50%;
          top: 42%;
          transform: translate(-50%,-50%);
          background: rgba(59,130,246,.18);
          filter: blur(90px);
          animation: introOrbThree 4s ease-in-out infinite;
        }

        .intro-content {
          position: relative;
          z-index: 5;
          width: min(90vw, 520px);
          display: flex;
          flex-direction: column;
          align-items: center;
          text-align: center;
          animation: introContentIn 1.1s cubic-bezier(.22,1,.36,1) .1s both;
        }

        .intro-logo-wrap {
          position: relative;
          width: 145px;
          height: 145px;
          display: flex;
          align-items: center;
          justify-content: center;
          margin-bottom: 30px;
        }

        .intro-logo-glow {
          position: absolute;
          width: 125px;
          height: 125px;
          border-radius: 50%;
          background: radial-gradient(circle, rgba(59,130,246,.55), rgba(6,182,212,.25) 42%, transparent 72%);
          filter: blur(10px);
          animation: introLogoGlow 2s ease-in-out infinite;
        }

        .intro-logo-ring {
          position: absolute;
          border-radius: 50%;
          border: 1px solid rgba(96,165,250,.38);
          pointer-events: none;
        }

        .intro-ring-one {
          width: 128px;
          height: 128px;
          animation: introRingOne 2.5s cubic-bezier(.22,1,.36,1) infinite;
        }

        .intro-ring-two {
          width: 150px;
          height: 150px;
          border-color: rgba(34,211,238,.22);
          animation: introRingTwo 3s cubic-bezier(.22,1,.36,1) infinite;
        }

        .intro-logo {
          position: relative;
          z-index: 4;
          width: 92px;
          height: 92px;
          overflow: hidden;
          border-radius: 27px;
          background: white;
          border: 2px solid rgba(255,255,255,.85);
          box-shadow: 0 0 0 8px rgba(255,255,255,.035), 0 0 35px rgba(59,130,246,.35), 0 18px 50px rgba(0,0,0,.35);
          animation: introLogoFloat 2.8s ease-in-out infinite;
        }

        .intro-logo::after {
          content: "";
          position: absolute;
          inset: 0;
          background: linear-gradient(135deg, rgba(255,255,255,.30), transparent 42%, rgba(34,211,238,.12));
          pointer-events: none;
        }

        .intro-logo img {
          width: 100%;
          height: 100%;
          display: block;
          object-fit: cover;
        }

        .intro-brand {
          opacity: 0;
          animation: introBrandIn .8s cubic-bezier(.22,1,.36,1) .45s forwards;
        }

        .intro-brand h1 {
          margin: 0;
          font-size: clamp(32px, 8vw, 48px);
          line-height: 1;
          font-weight: 900;
          letter-spacing: -.045em;
          color: #fff;
          text-shadow: 0 5px 25px rgba(0,0,0,.25);
        }

        .intro-brand h1 span {
          background: linear-gradient(135deg, #60a5fa, #22d3ee);
          -webkit-background-clip: text;
          background-clip: text;
          -webkit-text-fill-color: transparent;
        }

        .intro-line {
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 9px;
          margin-top: 13px;
        }

        .intro-line span {
          width: 30px;
          height: 1px;
          background: linear-gradient(90deg, transparent, #60a5fa);
        }

        .intro-line span:last-child {
          background: linear-gradient(90deg, #22d3ee, transparent);
        }

        .intro-line p {
          margin: 0;
          font-size: 9px;
          font-weight: 800;
          letter-spacing: .30em;
          color: #94a3b8;
        }

        .intro-tagline {
          margin: 24px 0 0;
          font-size: clamp(13px, 3.5vw, 16px);
          font-weight: 500;
          letter-spacing: .08em;
          color: #cbd5e1;
          opacity: 0;
          animation: introTaglineIn .8s ease .85s forwards;
        }

        .intro-loading {
          width: min(270px,70vw);
          margin-top: 32px;
          opacity: 0;
          animation: introLoadingIn .7s ease 1.1s forwards;
        }

        .intro-loading-track {
          position: relative;
          width: 100%;
          height: 3px;
          overflow: hidden;
          border-radius: 999px;
          background: rgba(148,163,184,.16);
        }

        .intro-loading-track span {
          position: absolute;
          left: 0;
          top: 0;
          width: 0%;
          height: 100%;
          border-radius: inherit;
          background: linear-gradient(90deg, #2563eb, #06b6d4, #60a5fa);
          box-shadow: 0 0 15px rgba(59,130,246,.75);
          animation: introLoading 2.45s cubic-bezier(.22,1,.36,1) .35s forwards;
        }

        .intro-loading p {
          margin: 11px 0 0;
          font-size: 9px;
          font-weight: 600;
          letter-spacing: .12em;
          color: #64748b;
        }

        .intro-corner {
          position: absolute;
          width: 65px;
          height: 65px;
          opacity: .55;
        }

        .intro-corner::before,
        .intro-corner::after {
          content: "";
          position: absolute;
          background: rgba(96,165,250,.45);
        }

        .intro-corner::before {
          width: 100%;
          height: 1px;
        }

        .intro-corner::after {
          width: 1px;
          height: 100%;
        }

        .intro-corner-tl { top: 28px; left: 28px; }
        .intro-corner-tr { top: 28px; right: 28px; transform: rotate(90deg); }
        .intro-corner-bl { bottom: 28px; left: 28px; transform: rotate(-90deg); }
        .intro-corner-br { bottom: 28px; right: 28px; transform: rotate(180deg); }

        /* =================================================
            THEME GLOW
        ================================================= */

        .theme-change-glow {
          position: fixed;
          inset: 0;
          z-index: 999998;
          pointer-events: none;
          opacity: 0;
          background: radial-gradient(circle at var(--theme-x,50%) var(--theme-y,50%), rgba(59,130,246,.18), rgba(59,130,246,.06) 22%, transparent 48%);
          transform: scale(.8);
          mix-blend-mode: screen;
        }

        html.theme-changing .theme-change-glow {
          opacity: 1;
          animation: themeGlow .8s cubic-bezier(.22,1,.36,1);
        }

        @keyframes themeGlow {
          0% { opacity: 0; transform: scale(.78); }
          20% { opacity: 1; }
          65% { opacity: .65; }
          100% { opacity: 0; transform: scale(1.15); }
        }

        /* =================================================
            BRAND
        ================================================= */

        .desktop-brand,
        .mobile-brand {
          text-decoration: none;
          color: inherit;
        }

        .desktop-brand {
          display: flex;
          align-items: center;
          gap: 12px;
          min-width: 240px;
          flex-shrink: 0;
        }

        .brand-logo {
          position: relative;
          overflow: hidden;
          flex-shrink: 0;
          background: rgba(255,255,255,.96);
          border: 1px solid rgba(255,255,255,.90);
          box-shadow: 0 7px 25px rgba(37,99,235,.12);
          transition: transform .4s ease, background-color .65s ease, border-color .65s ease;
        }

        .brand-logo img {
          position: relative;
          z-index: 1;
          width: 100%;
          height: 100%;
          object-fit: cover;
          display: block;
        }

        .desktop-brand-logo { width: 48px; height: 48px; border-radius: 15px; }
        .mobile-brand-logo { width: 43px; height: 43px; border-radius: 14px; }

        .brand-logo-glow {
          position: absolute;
          inset: 0;
          z-index: 2;
          pointer-events: none;
          background: linear-gradient(135deg, rgba(59,130,246,.12), transparent 45%, rgba(34,211,238,.10));
        }

        .brand-logo-border {
          position: absolute;
          inset: 1px;
          z-index: 3;
          border-radius: inherit;
          border: 1px solid rgba(255,255,255,.65);
          pointer-events: none;
        }

        .dark .brand-logo {
          background: #1e293b;
          border-color: #334155;
          box-shadow: 0 8px 25px rgba(0,0,0,.35);
        }

        .dark .brand-logo-border {
          border-color: rgba(148,163,184,.12);
        }

        .desktop-brand:hover .brand-logo,
        .mobile-brand:hover .brand-logo {
          transform: translateY(-2px) scale(1.035) rotate(-1deg);
        }

        .brand-text,
        .mobile-brand-text {
          display: flex;
          flex-direction: column;
          justify-content: center;
          min-width: 0;
          line-height: 1;
        }

        .brand-text h1,
        .mobile-brand-text h1 {
          margin: 0;
          padding: 0;
          font-weight: 900;
          letter-spacing: -.025em;
          color: #0f172a;
          white-space: nowrap;
        }

        .brand-text h1 { font-size: 18px; }
        .mobile-brand-text h1 { font-size: 15px; }

        .brand-text h1 span,
        .mobile-brand-text h1 span {
          color: #2563eb;
        }

        .dark .brand-text h1,
        .dark .mobile-brand-text h1 { color: #f8fafc; }
        .dark .brand-text h1 span,
        .dark .mobile-brand-text h1 span { color: #60a5fa; }

        .brand-sub {
          display: flex;
          align-items: center;
          gap: 6px;
          margin-top: 6px;
        }

        .brand-sub > span {
          width: 22px;
          height: 2px;
          border-radius: 999px;
          background: linear-gradient(90deg, #2563eb, #06b6d4);
        }

        .brand-sub p {
          margin: 0;
          padding: 0;
          font-size: 9px;
          font-weight: 800;
          letter-spacing: .14em;
          text-transform: uppercase;
          color: #64748b;
          white-space: nowrap;
        }

        .dark .brand-sub p { color: #94a3b8; }

        /* =================================================
            DESKTOP NAVBAR
        ================================================= */

        .desktop-navbar {
          position: fixed;
          top: 10px;
          left: 14px;
          right: 14px;
          z-index: 10000;
          height: 72px;
          display: flex;
          align-items: center;
          border-radius: 22px;
          background: rgba(255,255,255,.88);
          backdrop-filter: blur(24px);
          -webkit-backdrop-filter: blur(24px);
          border: 1px solid rgba(255,255,255,.75);
          box-shadow: 0 14px 50px rgba(15,23,42,.08);
        }

        .dark .desktop-navbar {
          background: rgba(15,23,42,.88);
          border-color: rgba(71,85,105,.45);
          box-shadow: 0 16px 55px rgba(0,0,0,.34);
        }

        .desktop-navbar-inner {
          width: 100%;
          max-width: 1540px;
          height: 100%;
          margin: 0 auto;
          padding: 0 14px;
          display: flex;
          align-items: center;
          gap: 10px;
        }

        .desktop-navigation {
          flex: 1;
          min-width: 0;
          display: flex;
          align-items: center;
          justify-content: center;
          padding: 0 10px;
        }

        .desktop-navigation-pill {
          display: flex;
          align-items: center;
          gap: 3px;
          padding: 4px;
          border-radius: 17px;
          background: rgba(248,250,252,.92);
          border: 1px solid #e2e8f0;
        }

        .dark .desktop-navigation-pill {
          background: rgba(15,23,42,.78);
          border-color: #334155;
        }

        .desktop-nav-link {
          position: relative;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 8px;
          padding: 9px 13px;
          border-radius: 13px;
          font-size: 13px;
          font-weight: 700;
          color: #64748b;
          text-decoration: none;
          white-space: nowrap;
          transition: color .35s ease, background-color .4s ease, transform .35s ease;
        }

        .desktop-nav-link:hover {
          color: #2563eb;
          background: #fff;
          transform: translateY(-1px);
        }

        .dark .desktop-nav-link { color: #cbd5e1; }
        .dark .desktop-nav-link:hover { color: #60a5fa; background: #1e293b; }

        .desktop-nav-link.active {
          color: white;
          background: linear-gradient(135deg, #1d4ed8, #2563eb, #0891b2);
          box-shadow: 0 6px 20px rgba(37,99,235,.25);
          animation: navActive .5s cubic-bezier(.22,1,.36,1);
        }

        @keyframes navActive {
          0% { opacity: .6; transform: scale(.94); }
          65% { transform: scale(1.035); }
          100% { opacity: 1; transform: scale(1); }
        }

        .desktop-actions {
          min-width: 240px;
          flex-shrink: 0;
          display: flex;
          align-items: center;
          justify-content: flex-end;
          gap: 9px;
        }

        .desktop-appointment {
          display: flex;
          align-items: center;
          gap: 8px;
          min-height: 39px;
          padding: 0 14px;
          border: none;
          border-radius: 13px;
          background: linear-gradient(135deg, #1d4ed8, #0891b2);
          color: white;
          font-size: 12px;
          font-weight: 800;
          cursor: pointer;
          box-shadow: 0 7px 18px rgba(37,99,235,.20);
          transition: transform .35s ease, box-shadow .35s ease;
        }

        .desktop-appointment:hover {
          transform: translateY(-2px) scale(1.015);
          box-shadow: 0 12px 28px rgba(37,99,235,.30);
        }

        /* =================================================
            THEME SWITCH
        ================================================= */

        .theme-switch {
          position: relative;
          display: flex;
          align-items: center;
          flex-shrink: 0;
          padding: 0;
          border-radius: 999px;
          overflow: hidden;
          cursor: pointer;
          isolation: isolate;
          transition: transform .45s ease, background-color .55s ease, border-color .55s ease;
        }

        .theme-switch:hover { transform: translateY(-1px) scale(1.045); }
        .theme-switch:active { transform: scale(.91); }

        .theme-switch-desktop { width: 66px; height: 36px; }
        .theme-switch-mobile { width: 58px; height: 32px; }

        .theme-switch-light {
          background: linear-gradient(135deg, #e0f2fe, #eff6ff);
          border: 1px solid #bfdbfe;
          box-shadow: 0 7px 20px rgba(37,99,235,.12);
        }

        .theme-switch-dark {
          background: linear-gradient(135deg, #020617, #172554);
          border: 1px solid #334155;
        }

        .theme-side-icon {
          position: absolute;
          top: 50%;
          width: 16px;
          height: 16px;
          display: flex;
          align-items: center;
          justify-content: center;
          transform: translateY(-50%);
          pointer-events: none;
        }

        .theme-sun { left: 7px; color: #f97316; }
        .theme-moon { right: 7px; color: #64748b; opacity: .35; }

        .theme-switch-dark .theme-sun { opacity: .18; }
        .theme-switch-dark .theme-moon { opacity: 1; color: #fde047; }

        .theme-knob {
          position: absolute;
          top: 50%;
          width: 30px;
          height: 30px;
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          z-index: 3;
          transform: translateY(-50%);
          background: linear-gradient(145deg, #ffffff, #f8fafc);
          box-shadow: 0 4px 10px rgba(15,23,42,.18);
          transition: left .55s cubic-bezier(.22,1,.36,1), background .5s ease, transform .65s ease;
        }

        .theme-switch-desktop .theme-knob { left: 3px; }
        .theme-switch-mobile .theme-knob { width: 26px; height: 26px; left: 3px; }

        .theme-switch-dark .theme-knob {
          background: linear-gradient(145deg, #1e293b, #0f172a);
          transform: translateY(-50%) rotate(360deg);
        }

        .theme-switch-desktop.theme-switch-dark .theme-knob { left: 32px; }
        .theme-switch-mobile.theme-switch-dark .theme-knob { left: 28px; }

        .theme-knob-sun { color: #2563eb; }
        .theme-knob-moon { color: #facc15; }

        /* =================================================
            MOBILE NAVBAR & BACKDROP
        ================================================= */

        .mobile-navbar { display: none; }

        .mobile-backdrop {
          position: fixed;
          inset: 0;
          z-index: 9990;
          background: rgba(2,6,23,.50);
          backdrop-filter: blur(9px);
          -webkit-backdrop-filter: blur(9px);
          opacity: 0;
          visibility: hidden;
          pointer-events: none;
          transition: opacity .35s ease, visibility .35s ease;
        }

        .mobile-backdrop.show {
          opacity: 1;
          visibility: visible;
          pointer-events: auto;
        }

        /* =================================================
            MOBILE MENU
        ================================================= */

        .mobile-menu-panel {
          position: fixed;
          left: 8px;
          right: 8px;
          top: 40%;
          z-index: 9999;
          display: none;
          max-height: calc(100dvh - 88px);
          overflow-y: auto;
          overflow-x: hidden;
          scrollbar-width: none;
          padding: 12px;
          border-radius: 24px;
          background: rgba(255,255,255,.96);
          backdrop-filter: blur(26px);
          -webkit-backdrop-filter: blur(26px);
          border: 1px solid rgba(255,255,255,.72);
          box-shadow: 0 24px 70px rgba(15,23,42,.24);
          opacity: 0;
          visibility: hidden;
          pointer-events: none;
          transform: translateY(-18px) scale(.98);
          transform-origin: top center;
          transition: opacity .35s ease, visibility .35s ease, transform .45s cubic-bezier(.16,1,.3,1);
        }

        .mobile-menu-panel::-webkit-scrollbar { display: none; }

        .dark .mobile-menu-panel {
          background: rgba(15,23,42,.94);
          border-color: rgba(71,85,105,.50);
          box-shadow: 0 28px 90px rgba(0,0,0,.58);
        }

        .mobile-menu-panel.show {
          opacity: 1;
          visibility: visible;
          pointer-events: auto;
          transform: translateY(-54%) scale(1);
        }

        .mobile-menu-handle {
          display: flex;
          justify-content: center;
          padding: 1px 0 11px;
        }

        .mobile-menu-handle span,
        .appointment-handle span {
          width: 40px;
          height: 4px;
          border-radius: 999px;
          background: #cbd5e1;
        }

        .dark .mobile-menu-handle span,
        .dark .appointment-handle span { background: #475569; }

        .mobile-menu-options {
          display: flex;
          flex-direction: column;
          gap: 6px;
        }

        .mobile-menu-option {
          position: relative;
          min-height: 58px;
          padding: 8px 10px;
          display: flex;
          align-items: center;
          gap: 11px;
          border-radius: 18px;
          background: rgba(248,250,252,.86);
          color: #334155;
          font-size: 15px;
          font-weight: 700;
          text-decoration: none;
          opacity: 0;
          transform: translateY(12px);
          transition: opacity .35s ease, transform .45s ease, background-color .5s ease, color .4s ease;
        }

        .mobile-menu-panel.show .mobile-menu-option {
          opacity: 1;
          transform: translateY(0);
          transition-delay: var(--menu-delay);
        }

        .dark .mobile-menu-option {
          background: rgba(30,41,59,.82);
          color: #e2e8f0;
        }

        .mobile-menu-option:hover { transform: translateX(3px); }

        .mobile-menu-option.active {
          background: linear-gradient(135deg, #2563eb, #0891b2);
          color: white;
          box-shadow: 0 9px 24px rgba(37,99,235,.20);
        }

        .active-line {
          position: absolute;
          left: 0;
          top: 50%;
          transform: translateY(-50%);
          width: 4px;
          height: 27px;
          border-radius: 0 999px 999px 0;
          background: white;
        }

        .mobile-option-icon {
          width: 41px;
          height: 41px;
          border-radius: 13px;
          display: flex;
          align-items: center;
          justify-content: center;
          flex-shrink: 0;
          background: white;
          color: #2563eb;
          box-shadow: 0 3px 10px rgba(15,23,42,.06);
        }

        .dark .mobile-option-icon { background: #334155; color: #60a5fa; }

        .mobile-menu-option.active .mobile-option-icon {
          background: rgba(255,255,255,.15);
          color: white;
          box-shadow: none;
        }

        .mobile-option-name { flex: 1; }

        .mobile-option-arrow {
          width: 28px;
          height: 28px;
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          flex-shrink: 0;
          background: #e2e8f0;
          color: #64748b;
        }

        .dark .mobile-option-arrow { background: #475569; color: #cbd5e1; }

        .mobile-menu-option.active .mobile-option-arrow {
          background: rgba(255,255,255,.16);
          color: white;
        }

        .mobile-appointment-button {
          min-height: 60px;
          margin-top: 5px;
          border: none;
          border-radius: 18px;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 10px;
          background: linear-gradient(135deg, #1d4ed8, #0891b2);
          color: white;
          font-size: 15px;
          font-weight: 800;
          cursor: pointer;
          box-shadow: 0 10px 28px rgba(37,99,235,.24);
        }

        .mobile-appointment-icon {
          width: 38px;
          height: 38px;
          border-radius: 12px;
          background: rgba(255,255,255,.14);
          display: flex;
          align-items: center;
          justify-content: center;
        }

        /* =================================================
            COMPACT APPOINTMENT MODAL & STYLES
        ================================================= */

        .appointment-overlay {
          position: fixed;
          inset: 0;
          z-index: 20000;
          display: flex;
          align-items: center;
          justify-content: center;
          padding: 8px;
          background: rgba(2,6,23,.62);
          backdrop-filter: blur(10px);
          -webkit-backdrop-filter: blur(10px);
          animation: overlayIn .3s ease-out;
        }

        @keyframes overlayIn {
          from { opacity: 0; }
          to { opacity: 1; }
        }

        .appointment-modal {
          width: 100%;
          max-width: 380px;
          max-height: calc(100dvh - 16px);
          overflow-y: auto;
          scrollbar-width: none;
          border-radius: 20px;
          background: white;
          border: 1px solid rgba(255,255,255,.75);
          box-shadow: 0 20px 60px rgba(0,0,0,.25);
          animation: modalIn .4s cubic-bezier(.22,1,.36,1);
        }

        .appointment-modal::-webkit-scrollbar { display: none; }

        .dark .appointment-modal {
          background: #0f172a;
          border-color: #334155;
          box-shadow: 0 20px 60px rgba(0,0,0,.6);
        }

        @keyframes modalIn {
          from { opacity: 0; transform: translateY(15px) scale(.96); }
          to { opacity: 1; transform: translateY(0) scale(1); }
        }

        .appointment-handle {
          display: none;
          justify-content: center;
          padding-top: 8px;
        }

        .appointment-header {
          position: relative;
          overflow: hidden;
          padding: 14px 14px 12px;
          text-align: center;
          background: linear-gradient(135deg, #1d4ed8, #2563eb, #0891b2);
          color: white;
        }

        .appointment-header-glow {
          position: absolute;
          border-radius: 50%;
          filter: blur(30px);
          pointer-events: none;
        }

        .glow-one { width: 120px; height: 120px; right: -50px; top: -50px; background: rgba(103,232,249,.26); }
        .glow-two { width: 130px; height: 130px; left: -60px; bottom: -60px; background: rgba(147,197,253,.18); }

        .appointment-close {
          position: absolute;
          top: 8px;
          right: 8px;
          width: 28px;
          height: 28px;
          border: 1px solid rgba(255,255,255,.18);
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          background: rgba(255,255,255,.12);
          color: white;
          cursor: pointer;
          font-size: 12px;
        }

        .appointment-close:hover { transform: rotate(90deg) scale(1.05); }

        .appointment-icon {
          position: relative;
          width: 36px;
          height: 36px;
          margin: 0 auto;
          display: flex;
          align-items: center;
          justify-content: center;
          border-radius: 10px;
          background: rgba(255,255,255,.15);
          border: 1px solid rgba(255,255,255,.18);
          font-size: 15px;
        }

        .appointment-header h2 {
          position: relative;
          margin: 8px 0 0;
          font-size: 18px;
          font-weight: 800;
        }

        .appointment-header p {
          position: relative;
          margin: 3px 0 0;
          font-size: 10px;
          color: #dbeafe;
        }

        .appointment-form {
          padding: 10px 14px 12px;
        }

        .appointment-field {
          margin-bottom: 6px;
        }

        .appointment-field label {
          display: block;
          margin-bottom: 2px;
          padding-left: 2px;
          font-size: 10px;
          font-weight: 700;
          color: #475569;
        }

        .dark .appointment-field label { color: #cbd5e1; }

        .appointment-input-wrap {
          position: relative;
          display: flex;
          align-items: center;
        }

        .appointment-input-wrap > span {
          position: absolute;
          left: 6px;
          width: 26px;
          height: 26px;
          border-radius: 8px;
          display: flex;
          align-items: center;
          justify-content: center;
          background: #eff6ff;
          color: #2563eb;
          font-size: 11px;
          z-index: 2;
          pointer-events: none;
        }

        .appointment-textarea-wrap > span {
          top: 8px;
          transform: none;
        }

        .dark .appointment-input-wrap > span {
          background: rgba(37,99,235,.15);
          color: #60a5fa;
        }

        .appointment-input-wrap input,
        .appointment-input-wrap select {
          width: 100%;
          min-height: 36px;
          padding: 6px 8px 6px 38px;
          border: 1px solid #e2e8f0;
          border-radius: 10px;
          outline: none;
          background: #f8fafc;
          color: #0f172a;
          font-size: 11px;
        }

        .appointment-textarea-wrap textarea {
          width: 100%;
          min-height: 75px;
          max-height: 120px;
          padding: 8px 8px 8px 38px;
          border: 1px solid #e2e8f0;
          border-radius: 10px;
          outline: none;
          background: #f8fafc;
          color: #0f172a;
          font-size: 11px;
          font-family: inherit;
          resize: vertical;
          line-height: 1.4;
        }

        .appointment-input-wrap input::placeholder,
        .appointment-textarea-wrap textarea::placeholder {
          color: #94a3b8;
        }

        .appointment-input-wrap input:focus,
        .appointment-input-wrap select:focus,
        .appointment-textarea-wrap textarea:focus {
          border-color: #3b82f6;
          background: white;
          box-shadow: 0 0 0 3px rgba(59,130,246,.10);
        }

        .dark .appointment-input-wrap input,
        .dark .appointment-input-wrap select,
        .dark .appointment-textarea-wrap textarea {
          background: #1e293b;
          border-color: #334155;
          color: #f8fafc;
        }

        .appointment-input-wrap select {
          appearance: none;
          -webkit-appearance: none;
          cursor: pointer;
        }

        .appointment-submit {
          width: 100%;
          min-height: 38px;
          margin-top: 4px;
          padding: 4px 8px 4px 12px;
          border: none;
          border-radius: 10px;
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 8px;
          background: linear-gradient(135deg, #1d4ed8, #0891b2);
          color: white;
          font-size: 11px;
          font-weight: 800;
          cursor: pointer;
          box-shadow: 0 6px 16px rgba(37,99,235,.2);
        }

        .appointment-submit:disabled { opacity: .7; cursor: not-allowed; }

        .appointment-submit span {
          display: flex;
          align-items: center;
          gap: 6px;
        }

        .appointment-submit > i {
          width: 28px;
          height: 28px;
          border-radius: 8px;
          display: flex;
          align-items: center;
          justify-content: center;
          background: rgba(255,255,255,.14);
          font-size: 11px;
        }

        .appointment-note {
          margin: 4px 0 0;
          text-align: center;
          font-size: 9px;
          color: #94a3b8;
        }

        /* =================================================
            WHATSAPP
        ================================================= */

        .wellborn-global-whatsapp {
          position: fixed;
          right: 16px;
          bottom: 16px;
          width: 52px;
          height: 52px;
          z-index: 999999;
          display: flex;
          align-items: center;
          justify-content: center;
          text-decoration: none;
          isolation: isolate;
        }

        .wellborn-whatsapp-pulse {
          position: absolute;
          inset: -14px;
          border-radius: 50%;
          background: radial-gradient(circle, rgba(37,211,102,.55) 0%, rgba(37,211,102,.30) 35%, rgba(37,211,102,.12) 60%, transparent 75%);
          filter: blur(3px);
          animation: whatsappGlow 1.8s ease-in-out infinite;
          z-index: 0;
        }

        .wellborn-global-whatsapp::before {
          content: "";
          position: absolute;
          width: 42px;
          height: 42px;
          border-radius: 50%;
          border: 1.5px solid rgba(37,211,102,.55);
          animation: whatsappRingOne 2.2s cubic-bezier(.22,1,.36,1) infinite;
          z-index: -1;
        }

        .wellborn-global-whatsapp::after {
          content: "";
          position: absolute;
          width: 42px;
          height: 42px;
          border-radius: 50%;
          border: 1px solid rgba(37,211,102,.35);
          animation: whatsappRingTwo 2.2s cubic-bezier(.22,1,.36,1) infinite;
          animation-delay: .75s;
          z-index: -1;
        }

        .wellborn-whatsapp-button {
          position: relative;
          z-index: 5;
          width: 44px;
          height: 44px;
          display: flex;
          align-items: center;
          justify-content: center;
          border-radius: 50%;
          background: linear-gradient(145deg, #32e875 0%, #20c863 48%, #16ad53 100%);
          border: 2px solid rgba(255,255,255,.9);
          box-shadow: 0 8px 22px rgba(37,211,102,.35), 0 2px 5px rgba(0,0,0,.10), inset 0 1px 2px rgba(255,255,255,.45);
          transition: transform .35s cubic-bezier(.22,1,.36,1), box-shadow .35s ease;
        }

        .wellborn-whatsapp-button::before {
          content: "";
          position: absolute;
          top: 4px;
          left: 7px;
          width: 15px;
          height: 7px;
          border-radius: 50%;
          background: rgba(255,255,255,.28);
          filter: blur(1px);
          transform: rotate(-25deg);
          pointer-events: none;
        }

        .wellborn-whatsapp-button svg {
          width: 22px;
          height: 22px;
          display: block;
          fill: white;
          filter: drop-shadow(0 1px 2px rgba(0,0,0,.15));
        }

        .wellborn-global-whatsapp:hover .wellborn-whatsapp-button {
          transform: translateY(-4px) scale(1.08);
          box-shadow: 0 12px 28px rgba(37,211,102,.42), 0 3px 8px rgba(0,0,0,.12), inset 0 1px 2px rgba(255,255,255,.5);
        }

        .wellborn-global-whatsapp:active .wellborn-whatsapp-button {
          transform: scale(.88);
        }

        @keyframes whatsappGlow {
          0% { transform: scale(.72); opacity: .35; }
          50% { transform: scale(1.35); opacity: 1; }
          100% { transform: scale(.72); opacity: .35; }
        }

        @keyframes whatsappRingOne {
          0% { transform: scale(.75); opacity: .75; }
          65% { transform: scale(1.65); opacity: 0; }
          100% { transform: scale(1.65); opacity: 0; }
        }

        @keyframes whatsappRingTwo {
          0% { transform: scale(.75); opacity: .55; }
          65% { transform: scale(1.85); opacity: 0; }
          100% { transform: scale(1.85); opacity: 0; }
        }

        /* =================================================
            TABLET / MOBILE RESPONSIVE
        ================================================= */

        @media (max-width: 1023px) {
          .desktop-navbar { display: none; }

          .mobile-navbar {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 10000;
            height: 62px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0;
            background: rgba(255,255,255,.96);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border: none;
            box-shadow: 0 8px 28px rgba(15,23,42,.08);
          }

          .dark .mobile-navbar {
            background: rgba(15,23,42,.96);
            box-shadow: 0 10px 32px rgba(0,0,0,.30);
          }

          .user-main { padding-top: 70px; }

          .mobile-brand {
            display: flex;
            align-items: center;
            min-width: 0;
            flex: 1;
            gap: 9px;
          }

          .mobile-actions {
            margin-left: 8px;
            display: flex;
            align-items: center;
            gap: 6px;
            flex-shrink: 0;
          }

          .mobile-menu-button {
            width: 40px;
            height: 40px;
            border: none;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(135deg, #1d4ed8, #2563eb);
            color: white;
            font-size: 15px;
            cursor: pointer;
            box-shadow: 0 6px 18px rgba(37,99,235,.20);
            transition: transform .4s ease, box-shadow .35s ease;
          }

          .mobile-menu-button:hover { transform: translateY(-1px) scale(1.04); }
          .mobile-menu-button:active { transform: scale(.88); }
          .mobile-menu-button.menu-button-open { transform: rotate(90deg); }

          .mobile-menu-panel { display: block; top: 78px !important; }
          .mobile-menu-panel.show { transform: translateY(0) scale(1) !important; }
        }

        @media (max-width: 640px) {
          .mobile-navbar {
            position: fixed;
            top: 0 !important;
            left: 0 !important;
            right: 0 !important;
            width: 100vw !important;
            max-width: 100vw !important;
            height: 70px;
            margin: 0 !important;
            padding: 0 10px;
            border-radius: 0 !important;
          }

          .mobile-brand-logo { width: 41px; height: 41px; border-radius: 14px; }
          .mobile-brand-text h1 { font-size: 14px; }
          .brand-sub { margin-top: 5px; }
          .brand-sub > span { width: 18px; }
          .brand-sub p { font-size: 8px; }
          .mobile-menu-button { width: 39px; height: 39px; }

          .mobile-menu-panel { left: 6px; right: 6px; max-height: 83dvh; padding: 10px; }
          .mobile-menu-option { min-height: 56px; border-radius: 17px; font-size: 14px; }
          .mobile-appointment-button { min-height: 58px; border-radius: 17px; }

          .appointment-overlay { padding: 6px; }
          .appointment-modal { max-width: 100%; max-height: 94dvh; border-radius: 18px; }
          .appointment-handle { display: flex; }
          .appointment-header { padding: 12px; }
          .appointment-form { padding: 8px 12px 10px; }

          .wellborn-global-whatsapp { right: 12px; bottom: 12px; width: 52px; height: 52px; }
          .wellborn-whatsapp-button { width: 52px; height: 52px; }
          .wellborn-whatsapp-button svg { width: 26px; height: 26px; }
        }

        /* =================================================
            STYLISH TREATMENT SELECTOR CSS
        ================================================= */

        .stylish-treatments-grid {
          display: grid;
          grid-template-columns: repeat(2, 1fr);
          gap: 6px;
          margin-top: 4px;
        }

        .treatment-pill {
          display: flex;
          align-items: center;
          gap: 8px;
          padding: 8px 10px;
          border-radius: 10px;
          border: 1px solid #e2e8f0;
          background: #f8fafc;
          color: #475569;
          font-size: 11px;
          font-weight: 700;
          cursor: pointer;
          text-align: left;
          transition: all 0.25s ease;
        }

        .dark .treatment-pill {
          background: #1e293b;
          border-color: #334155;
          color: #cbd5e1;
        }

        .treatment-pill i {
          font-size: 12px;
          color: #2563eb;
          transition: color 0.25s ease;
        }

        .dark .treatment-pill i { color: #60a5fa; }

        .treatment-pill:hover {
          border-color: #3b82f6;
          background: #eff6ff;
          transform: translateY(-1px);
        }

        .dark .treatment-pill:hover {
          background: rgba(37,99,235,0.15);
          border-color: #3b82f6;
        }

        .treatment-pill.selected {
          background: linear-gradient(135deg, #1d4ed8, #0891b2);
          border-color: transparent;
          color: white;
          box-shadow: 0 4px 12px rgba(37,99,235,0.25);
        }

        .treatment-pill.selected i { color: white; }

        @media (max-width: 480px) {
          .stylish-treatments-grid { grid-template-columns: repeat(2, 1fr); gap: 5px; }
          .treatment-pill { padding: 7px 8px; font-size: 10px; }
        }
      `}</style>
    </div>
  );
}